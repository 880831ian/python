#!/usr/bin/python
# coding: utf-8
x = 3285
print (bin(x))
print (oct(x))
print (hex(x))

