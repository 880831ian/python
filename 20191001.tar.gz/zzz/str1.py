#!/usr/bin/python
# coding: utf-8

var1 = "abc123cde" #我的第一個變數
print var1		
print var1[3]
print var1[2:6]	
print var1[3:]			
print var1 * 2 + "CYUT"	
