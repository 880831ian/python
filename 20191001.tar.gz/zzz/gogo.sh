today=`date +%Y%m%d`
nowtime=`date +%T`
name=`cat ../sid`
a="\e[32m";b="\e[0m";c="\e[31m";
d="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

t1=abc
t2=my1
t3=my2
t4=str1
t5=underscore1
t6=underscore1test
t7=underscore2
t8=underscore2test

clear

echo ${d};
echo "             Python 執行腳本 "
echo "執行日期：${today} 執行時間：${nowtime}"
echo -e "${a}學號姓名檔案from /home/dywang/sid${b}"
${name}
chmod a+x *.py
echo -e "${a}以更改權限 chmod a+x${b}"
echo -e "${a}輸出${t1}.py  以下執行結果${b}"
./${t1}.py
echo ${d};
echo -e "${a}輸出${t2}.py  以下執行結果${b}"
./${t2}.py
echo ${d};
echo -e "${a}輸出${t3}.py  以下執行結果${b}"
./${t3}.py
echo ${d};
echo -e "${a}輸出${t4}.py  以下執行結果${b}"
./${t4}.py
echo ${d};
echo -e "${a}輸出${t5}.py  以下執行結果${b}"
./${t5}.py
echo ${d};
echo -e "${a}輸出${t6}.py  以下執行結果${b}"
./${t6}.py
echo ${d};
echo -e "${a}輸出${t7}.py  以下執行結果${b}"
./${t7}.py
echo ${d};
echo -e "${a}輸出${t8}.py  以下執行結果${b}"
./${t8}.py
echo ${d};


