#!/usr/bin/python
# coding: utf-8
x = "ABC"
y = "123"
z = x + "\n" + y 
print (z)

