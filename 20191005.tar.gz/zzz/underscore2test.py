#!/usr/bin/python

from underscore2 import *

myc1.__name__
myc1()._myc1__method()

