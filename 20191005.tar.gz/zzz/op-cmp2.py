#!/usr/bin/python
# coding: utf-8
x = 41
y = -58
print (x>y,x<y,x>=y,x<=y)
