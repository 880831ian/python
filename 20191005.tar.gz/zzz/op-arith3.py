#!/usr/bin/python
# coding: utf-8
x = 21.8
y = 7
z = -52.9
print (x//y,z//y)
