#!/usr/bin/python
# coding: utf-8
x = 27
print (bin(x),bin(~x))
