#!/usr/bin/python
# coding: utf-8
x = 16.7
y = int(x)+218
print(y,type(y))

