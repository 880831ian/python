#!/usr/bin/python
# coding: utf-8
x = 27
y = 69
print (bin(x),bin(y))
