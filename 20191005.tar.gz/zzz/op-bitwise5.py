#!/usr/bin/python
# coding: utf-8
x = 237
print (bin(x),bin(x>>3))
