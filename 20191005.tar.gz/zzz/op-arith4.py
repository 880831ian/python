#!/usr/bin/python
# coding: utf-8
x = 121
y = 43
z = 2.1
print ((x/y)**z)
