#!/usr/bin/python
# coding: utf-8
x = 16
y = float(x)+351
print(y,type(y))

