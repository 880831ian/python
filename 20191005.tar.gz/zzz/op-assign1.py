#!/usr/bin/python
# coding: utf-8
x=14;y=5;x+=y; print(x)
x=14;y=5;x-=y; print(x)
x=14;y=5;x*=y; print(x)
x=14;y=5;x/=y; print(x)
