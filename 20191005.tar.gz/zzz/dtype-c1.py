#!/usr/bin/python
# coding: utf-8
x = 21
y = 85
print (chr(x),chr(y))

