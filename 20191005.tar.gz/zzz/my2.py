#!/usr/bin/python
if True:
	print "yes"
	print "true"
else:
	print "No"
	print "false"
