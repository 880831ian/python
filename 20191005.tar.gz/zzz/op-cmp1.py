#!/usr/bin/python
# coding: utf-8
x = 21
y = 85
print (x==y,x!=y,x<>y)
