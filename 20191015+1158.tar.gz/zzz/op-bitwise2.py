#!/usr/bin/python
# coding: utf-8
x = 27
y = 69
z = x&y
z1 = x|y
z2 = x^y
print bin(z),bin(z1),bin(z2)
