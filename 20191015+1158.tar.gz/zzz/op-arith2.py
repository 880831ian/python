#!/usr/bin/python
# coding: utf-8
x = 21
y = 2.1
print (x**y)
