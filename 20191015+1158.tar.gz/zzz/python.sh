today=`date +%Y%m%d`
nowtime=`date +%T`
name=`date +%Y%m%d+%H%M`
rm -rf ../sid
sid=`ifconfig eth1 | grep 'inet ' | sed 's/.*addr:192.168.1.//' | sed 's/ .*//'`
echo "1-3 $sid 10627046 莊品毅" >../sid
a="\e[32m";b="\e[0m";c="\e[31m";d="\e[34m"
x="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo -e ${d}${x}${b};
echo "            Python 執行腳本 "
echo "執行日期：${today} 執行時間：${nowtime}"
echo -e "${a}學號姓名檔案from /home/dywang/sid${b}"
cat ../sid
chmod a+x *.py
echo -e "${a}已更改權限 chmod a+x${b}"

for ((i=0; i<49; i++));do
t=(
abc
my1
my2
str1
underscore1
underscore1test
underscore2
underscore2test
dtype-type1
dtype-type2
dtype-dec
dtype-bin
dtype-ft1
dtype-ft2
dtype-math1
dtype-math2
dtype-math3
dtype-bool1
dtype-bool2
dtype-str1
dtype-str2
dtype-str3
dtype-str4
dtype-c1
dtype-c2
dtype-c3
dtype-c4
op-arith1
op-arith2
op-arith3
op-arith4
op-cmp1
op-cmp2
op-assign1
op-assign2
op-assign3
op-bitwise1
op-bitwise2
op-bitwise3
op-bitwise4
op-bitwise5
if1
if-else1
if-elif-else1
nested-if1
list-sum1
list-change1
list-add1
list-del1
)
num=`expr $num + 1`;
echo -e "${c}[第 ${num} 題]${b} ${a}輸出${t[i]}.py  以下執行結果${b}"
./${t[i]}.py
echo -e ${d}${x}${b};
done

echo -e "目前題數：(${a}${num}${b})";
[ -n "$1" ] && touch /tmp/$1 && echo -e "${a}以新增驗證檔案$1${b}"
cd;tar zcvf ${name}.tar.gz zzz/ 1>/dev/null
mv ${name}.tar.gz /home/dywang/Desktop/
echo -e "${a}壓縮備份檔案成功! 已將檔案存在/home/dywang/Desktop/${b}";
echo -e ${d}${x}${b};
