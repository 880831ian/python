#!/bin/bash

action=$(basename $0)
action=${action%.sh}
laction=/tmp/${action%network}local.sh
kvm=kvm6.deyu.wang
kvmpw=123qweasd
source /tmp/printyn.sh
declare -i number=$RANDOM*4/32767+5

cd /home/dywang/zzz || exit
#cd /home/dywang/Documents/latex/linuxprogram/py 2>/dev/null

if false; then     ############################IF############################

file='abc.py'
egrep -q 'bin/(python|env)' $file && grep -q 'print' $file && test "$(./$file)" -eq "7"
print_yn $? $file

file='my1.py'
egrep -q 'bin/(python|env)' $file && grep -q 'print' $file && test "$(./$file)" -eq "9"
print_yn $? $file

file='my2.py'
egrep -q 'bin/(python|env)' $file && grep -q 'print' $file && ./$file | grep -q 'yes' && ./$file | grep -q 'true'
print_yn $? $file

for i in 1 2 3; do
	test -f vi$i.txt && diff -quN /tmp/vi$i vi$i.txt
	print_yn $? vi$i
done
#rm -f /tmp/vi*

fi #######################FI##################################

file='str1.py'
egrep -q 'bin/(python|env)' $file && grep -q '我的第一個變數' $file && \
a=$(./$file) && echo $a | grep -q "abc123cde 1 c123 123cde abc123cdeabc123cdeCYUT"
print_yn $? $file

file='underscore1.py'
egrep -q 'bin/(python|env)' $file && grep -q '__main__' $file && \
a=$(./$file) && echo $a | grep -q "__main__ myc1 _myc2"
print_yn $? $file

file='underscore1test.py'
egrep -q 'bin/(python|env)' $file && grep -q 'underscore1' $file && \
! a=$(./$file 2>&1) && echo $a | grep -q "underscore1 myc1 Traceback.*is not defined"
print_yn $? $file


file='underscore2.py'
egrep -q 'bin/(python|env)' $file && grep -q '__main__' $file && \
a=$(./$file) && echo $a | grep -q "__main__ myc1 myc1 method1 in class myc1"
print_yn $? $file

file='underscore2test.py'
egrep -q 'bin/(python|env)' $file && grep -q 'underscore2' $file && \
a=$(./$file 2>&1) && echo $a | grep -q "underscore2 myc1 method1 in class myc1"
print_yn $? $file

file='dtype-type1.py'
egrep -q 'bin/(python|env)' $file && grep -q '變數 *x' $file && \
a=$(./$file) && echo $a | grep -q "(5, <type 'int'>)"
print_yn $? $file

file='dtype-type2.py'
egrep -q 'bin/(python|env)' $file && grep -q '變數 *x' $file && \
a=$(./$file) && echo $a | grep -q "(5.0, <type 'float'>)"
print_yn $? $file

file='dtype-dec.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "11 3725 24546"
print_yn $? $file

file='dtype-bin.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "0b110011010101 06325 0xcd5"
print_yn $? $file

file='dtype-ft1.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(367.0, <type 'float'>)"
print_yn $? $file

file='dtype-ft2.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(234, <type 'int'>)"
print_yn $? $file

file='dtype-math1.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(7.5999999999999996, 2.3999999999999999)"
print_yn $? $file

file='dtype-math2.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "0.00128942047738"
print_yn $? $file

file='dtype-math3.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(-8.0, 2.0)"
print_yn $? $file

file='dtype-bool1.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(True, False)"
print_yn $? $file

file='dtype-bool2.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(1, 0)"
print_yn $? $file

file='dtype-str1.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(\"Linda's friend\", <type 'str'>)"
print_yn $? $file

file='dtype-str2.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "Linda's friendCSIE CYUT"
print_yn $? $file

file='dtype-str3.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "123456"
print_yn $? $file

file='dtype-str4.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "123123123456456"
print_yn $? $file

file='dtype-c1.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "('\\\\x15', 'U')"
print_yn $? $file

file='dtype-c2.py'
egrep -q 'bin/(python|env)' $file && \
a=$(./$file) && echo $a | grep -q "(71, 57)"
print_yn $? $file

file='dtype-c3.py'
egrep -q 'bin/(python|env)' $file && grep -q "+ *['\"]\\\\n['\"] *+" $file && \
a=$(./$file) && echo $a | grep -q "ABC 123"
print_yn $? $file

file='dtype-c4.py'
egrep -q 'bin/(python|env)' $file && grep -q '\\n' $file && \
test "$(./$file | wc -l)" -eq "3" && a=$(./$file) && echo $a | grep -q 'ABC 123 ABC\\n123'
print_yn $? $file

#egrep -q 'bin/(python|env)' $file && grep -q '\\n' $file && \
#test "$(./$file | wc -l)" -eq "3" && a=$(./$file) && echo $a | grep -q '106 -64 1785 0 21'
#print_yn $? $file

file='op-arith1.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *% *y' $file && \
a=$(./$file) && echo $a | grep -q '106 -64 1785 0 21'
print_yn $? $file

file='op-arith2.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *\*\* *y' $file && \
a=$(./$file) && echo $a | grep -q '597.944009052'
print_yn $? $file

file='op-arith3.py'
egrep -q 'bin/(python|env)' $file && grep -q '//' $file && \
a=$(./$file) && echo $a | grep -q '3.0 -8.0'
print_yn $? $file

file='op-arith4.py'
egrep -q 'bin/(python|env)' $file && grep -q '/.*\*\*' $file && \
a=$(./$file) && echo $a | grep -q '4.28709385015'
print_yn $? $file

file='op-cmp1.py'
egrep -q 'bin/(python|env)' $file && grep -q '!=.*<>' $file && \
a=$(./$file) && echo $a | grep -q 'False True True'
print_yn $? $file

file='op-cmp2.py'
egrep -q 'bin/(python|env)' $file && grep -q '>=.*<=' $file && \
a=$(./$file) && echo $a | grep -q 'True False True False'
print_yn $? $file

file='op-assign1.py'
egrep -q 'bin/(python|env)' $file && grep -q '/=' $file && \
a=$(./$file) && echo $a | grep -q '19 14 70 14'
print_yn $? $file

file='op-assign2.py'
egrep -q 'bin/(python|env)' $file && grep -q '%=' $file && \
a=$(./$file) && echo $a | grep -q '476 0'
print_yn $? $file

file='op-assign3.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *, *y *= *y *, *x *' $file && \
a=$(./$file) && echo $a | grep -q '291 12.1 12.1 291'
print_yn $? $file

file='op-bitwise1.py'
egrep -q 'bin/(python|env)' $file && grep -q 'bin(x)' $file && \
a=$(./$file) && echo $a | grep -q '0b11011 0b1000101'
print_yn $? $file

file='op-bitwise2.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *| *y' $file && \
a=$(./$file) && echo $a | grep -q '0b1 0b1011111 0b1011110'
print_yn $? $file

file='op-bitwise3.py'
egrep -q 'bin/(python|env)' $file && grep -q 'bin(~x)' $file && \
a=$(./$file) && echo $a | grep -q '0b11011 -0b11100'
print_yn $? $file

file='op-bitwise4.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *<< *2' $file && \
a=$(./$file) && echo $a | grep -q '0b11101101 0b1110110100'
print_yn $? $file

file='op-bitwise5.py'
egrep -q 'bin/(python|env)' $file && grep -q 'x *>> *3' $file && \
a=$(./$file) && echo $a | grep -q '0b11101101 0b11101'
print_yn $? $file




file='if1.py'
rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字串' $file && \
a=$(echo $rstr | ./$file) && echo $a | grep -q "請輸入一字串輸入的字串是：$rstr"
print_yn $? $file

file='if-else1.py'
rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字串' $file && \
a=$(echo $rstr | ./$file) && echo $a | grep -q "請輸入一字串輸入的字串是：$rstr" && \
a=$(echo '' | ./$file) && echo $a | grep -q "請輸入一字串沒有輸出任何字串"
print_yn $? $file

file='if-elif-else1.py'
if egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字元' $file; then
	rstr=$(cat /dev/urandom | tr -dc 'a-zE-Z' | fold -w 1 | head -n 1) && \
	a=$(echo $rstr | ./$file) && echo $a | grep -q "$rstr > D" && \
	rstr=$(cat /dev/urandom | tr -dc '0-9A-C' | fold -w 1 | head -n 1) && \
	a=$(echo $rstr | ./$file) && echo $a | grep -q "$rstr < D" && \
	a=$(echo D | ./$file) && echo $a | grep -q "D = D" 
	print_yn $? $file
else
	print_yn no_ch_str $file
fi

file='nested-if1.py'
if egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file; then
	rstr=$(cat /dev/urandom | tr -dc '1-9' | fold -w 5 | head -n 1) && \
	nu1=$((RANDOM%100+1000))
	nu2=$((RANDOM%500))
	nu3=$((RANDOM%400+500))
	echo $nu1 | ./$file | grep -q "$nu1 >= 1000" && \
	echo $nu2 | ./$file | grep -q "$nu2 < 500" && \
	echo $nu3 | ./$file | grep -q "$nu3 > 500" && \
	echo 500 | ./$file | grep -q "500 = 500"
	print_yn $? $file
else
	print_yn no_ch_str $file
fi


wget -qO list.txt https://dywang.csie.cyut.edu.tw/list.txt
file='list-sum1.py'
nu=$((RANDOM%10+1))
list1=$(grep list1 list.txt)
cat > test << EOF
$list1
var = str(min(list1))
var += ',' + str(max(list1))
var += ',' + str(sum(list1))
var += ',' + str(sum(list1)%$nu)
var += ',' + str(len(list1)*$nu)
print var
EOF
ans=$(python test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
echo -e "${nu}" | ./$file | grep -q "$ans"
print_yn $? $file

file='list-change1.py'
nu=$((RANDOM%10+1))
list2=$(grep list2 /tmp/list.txt)
cat > /zzz/test << EOF
$list2
list2[$nu-1] = $nu
print list2[$nu-2:$nu+1]
EOF
ans=$(python /tmp/test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
echo -e "${nu}" | ./$file | grep -q "$ans"
print_yn $? $file

file='list-add1.py'
list7=$(grep list7 /tmp/list.txt)
list8=$(grep list8 /tmp/list.txt)
list9=$(grep list9 /tmp/list.txt)
nu1=$((RANDOM%10+4))
nu2=$((RANDOM%2+2))

cat > /zzz/test << EOF
$list7
$list8
lista = list7 + list8
print lista
EOF
ans1=$(python /tmp/test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
cat > /zzz/test << EOF
$list9
lista = list9*$nu2
print lista
EOF
ans2=$(python /tmp/test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
echo -e "${nu1}" | ./$file | grep -q "$ans1" && \
echo -e "${nu2}" | ./$file | grep -q "$ans2"
print_yn $? $file

file='list-del1.py'
list3=$(grep list3 /tmp/list.txt)
nu=$((RANDOM%4+1))
cat > /zzz/test << EOF
$list3
del list3[$nu-1]
del list3[9:40:$nu]
print list3[$nu+1:$nu+5]
EOF
ans=$(python /tmp/test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
grep -q ^del $file && echo -e "${nu}" | ./$file | grep -q "$ans"
print_yn $? $file

exit ######################################################################


wget -qO /tmp/tuple.txt https://dywang.csie.cyut.edu.tw/tuple.txt
file='tuple-change1.py'
egrep -q 'bin/(python|env)' $file && grep -q 'tuple1\[1\] *= *.abc' $file && \
./$file 2>&1 | grep -q "object does not support item assignment"
print_yn $? $file

file='tuple-change2.py'
ans=$(grep tuple2 /tmp/tuple.txt | sed "s/(/(\'abc\', /" | grep -o '(.*)')
#echo $nu1,$nu2,$ans
egrep -q 'bin/(python|env)' $file && grep -q 'tuple2 *= *( *.abc' $file && \
./$file | grep -q "$ans"
print_yn $? $file

file='tuple-method1.py'
nu=$((RANDOM%10+1))
tuple8=$(grep tuple8 /tmp/tuple.txt)
cat > /tmp/test << EOF
$tuple8
var = str(min(tuple8))
var += ',' + str(max(tuple8))
var += ',' + str(sum(tuple8))
var += ',' + str(sum(tuple8)%$nu)
var += ',' + str(len(tuple8)*$nu)
print var
EOF
ans=$(python /tmp/test)
#echo $nu1,$nu2,$ans
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
echo $nu | ./$file | grep -q "$ans"
print_yn $? $file

file='tuple-list1.py'
nu=$((RANDOM%10+1))
tuple8=$(grep tuple8 /tmp/tuple.txt)
cat > /tmp/test << EOF
$tuple8
list8=list(tuple8)
del list8[3:45:$nu]
print list8[$nu+1:$nu+5]
EOF
ans=$(python /tmp/test | sed 's/\[/\\\[/' | sed 's/\]/\\\]/')
#echo $nu1,$nu2,$ans
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
grep -q ^del $file && echo $nu | ./$file | grep -q "$ans"
print_yn $? $file

####################BEGIN loop###########################
file='while1.py'
nu=$((RANDOM%80+1))
sum=0
str=''
for ((i=1;i<=$nu;i++)); do
    str="${str}${i}+"
    ((sum+=i))
done
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
grep -q '^while' $file && echo $nu | ./$file | grep -q "${str%+}=$sum"
print_yn $? $file

exit
file='for1.py'
#nu=$(cat /dev/urandom | tr -dc '1-9' | fold -w 2 | head -n 1)
rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 10 | head -n 1)
str=$(echo $rstr | cut -c2-9 | sed 's/\(.\)/\1=/g')
#echo aaaaa=$rstr,$str,$str1,${str1%=}
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字串' $file && \
grep -q '^for' $file && echo $rstr | ./$file | grep -q "${str%=}"
print_yn $? $file

file='range1.py'
nu1=$((RANDOM%10+1))
nu2=$((RANDOM%11+10))
#echo aaaaa=$nu1,$nu2
sum=0
for ((i=$nu1;i<=$nu2;i++)); do
    [ "$((i%3))" -eq "0" ] && ((sum+=i))
done
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一.*限值' $file && \
grep -q 'range' $file && echo -e "$nu1\n$nu2" | ./$file | grep -q "總和=${sum}"
print_yn $? $file

file='range2.py'
nu1=$((RANDOM%10+1))
nu2=$((RANDOM%30+11))
sum=0
for ((i=$nu1;i<=$nu2;i++)); do
    ((sum+=i))
done
sidx=$(cat ../sid | awk '{print $3 "\t" $4 "\t"}')
egrep -q 'bin/(python|env)' $file && \
echo -e "${nu1}\n${nu2}" | ./$file | grep -q "$sidx$sum" 
print_yn $? $file

file='nested-for1.py'
echo -e "\c" > /tmp/${file}.txt
nu=$((RANDOM%8+2))
for ((i=1;i<=nu;i++)); do
    str=''
    for ((j=1;j<2*nu;j++)); do
        tmp=$((j-nu)); tmp=${tmp#-}
        [ $tmp -lt $i ] && str=${str}$i || str="${str}-"
    done
    [ $i -le $nu ] && echo "${str}" >> /tmp/${file}.txt
done
#echo $str
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一數字' $file && \
echo -e "$nu\n" | ./$file  > /tmp/${file}.ttt
sidx=$(cat ../sid | awk '{print $3 "\t" $4}')
#echo iiiii,"$sidx"
grep -q "$sidx" /tmp/${file}.ttt && \
diff -I "$sidx" -uN /tmp/${file}.txt /tmp/${file}.ttt
print_yn $? $file
rm -f /tmp/${file}.t*

file='for-continue1.py'
rstr=$(cat /dev/urandom | tr -dc 'hjkg' | fold -w 20 | head -n 1)
str=$(echo $rstr | sed 's/h//g' | sed 's/\(.\)/\1=/g')
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字串' $file && \
grep -q '^for' $file && pcregrep -Mq 'if.*(\n|.)*continue' $file && \
echo $rstr | ./$file | grep -q "${str}"
print_yn $? $file

file='for-else1.py'
rstr0=$(cat /dev/urandom | tr -dc 'abcdefg' | fold -w 5 | head -n 1)
rstr1=a$(cat /dev/urandom | tr -dc 'hjkg' | fold -w 20 | head -n 1)
str=${rstr1%%h*}A
#echo ${str},${#str},${rstr1}
egrep -q 'bin/(python|env)' $file && grep -q '請輸入一字串' $file && \
grep -q '^for' $file && grep -q '^else' $file && \
echo $rstr1 | ./$file | grep -q "第 ${#str} 字元" && \
echo $rstr0 | ./$file | grep -q "找不到 h 字元"
print_yn $? $file
####################END loop###########################


wget -qO /tmp/dict-passwd.txt https://dywang.csie.cyut.edu.tw/dict-passwd.txt
file='dict-def1.py'
passtmp=$(awk -F\: '$3 > 50 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
cat > /tmp/test << EOF
passwd_dict1={$passtmp}
print passwd_dict1
EOF
python /tmp/test > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q 'print  *passwd_dict1' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

file='dict-add1.py'
passtmp=$(awk -F\: '$3 < 5 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
cat > /tmp/test << EOF
passwd_dict2={$passtmp}
passwd_dict2['deyu1']=1000
print passwd_dict2
EOF
python /tmp/test > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q 'print  *passwd_dict2' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

file='dict-change1.py'
cat > /tmp/test << EOF
passwd_dict2={$passtmp}
passwd_dict2['deyu1']=1001
print passwd_dict2
EOF
python /tmp/test > /tmp/$file.ans
#echo iiiii=$ans
egrep -q 'bin/(python|env)' $file && grep -q 'print  *passwd_dict2' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file


file='dict-verify1.py'
passtmp=$(awk -F\: '$3 < 10 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
rstr0=$(cat /dev/urandom | tr -dc 'abcdefg' | fold -w 5 | head -n 1)
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
passwd_dict3={$passtmp}
inkey = raw_input("請輸入一字串") 
if inkey in passwd_dict3:
	print inkey,passwd_dict3[inkey]
else:
	passwd_dict3[inkey] = 1122
	print passwd_dict3
EOF
echo $rstr0 | python /tmp/test > /tmp/$file.ans
#echo iiiii=$ans
egrep -q 'bin/(python|env)' $file && grep -q 'print  *passwd_dict3' $file && \
echo bin | ./$file | grep -q '^請輸入一字串bin 1$' && \
echo $rstr0 | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

file='dict-traverse1.py'
passtmp=$(awk -F\: '$3<=100 && $3>=60 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
passwd_dict4={$passtmp}
keys=''
valuesum=0
for key,value in passwd_dict4.items():
	keys+=key
	valuesum+=value
strtmp=keys + '\t' +str(valuesum)
print strtmp
EOF
python /tmp/test > /tmp/$file.ans
#echo iiiii=$ans
egrep -q 'bin/(python|env)' $file && grep -q 'passwd_dict4' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

file='dict-traverse2.py'
passtmp=$(awk -F\: '$3<=1000 && $3>=80 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
passwd_dict5={$passtmp}
keys=''
valuesum=0
for key,value in passwd_dict5.items():
	if len(key) <= 4:
		keys+=key
		valuesum+=value
strtmp=keys + '\t' +str(valuesum)
print strtmp
EOF
python /tmp/test > /tmp/$file.ans
#echo iiiii=$ans
egrep -q 'bin/(python|env)' $file && grep -q 'passwd_dict5' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file


file='dict-del1.py'
passtmp=$(awk -F\: '$3<=120 && $3>=30 {print $1 "\t" $3 |"sort -nk2"}' /tmp/dict-passwd.txt | sed "s/^/'/" | sed "s/\t/':/" | tr '\n' ',' | sed 's/,$//')
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
passwd_dict6={$passtmp}
for key,value in passwd_dict6.items():
	if value % 2 != 0:
		del passwd_dict6[key]
print passwd_dict6
EOF
python /tmp/test > /tmp/$file.ans
#echo iiiii=$ans
egrep -q 'bin/(python|env)' $file && grep -q '^print  *passwd_dict6' $file && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

file='fun-avg1.py'
nu1=$((RANDOM%100+1))
nu2=$((RANDOM%100+1))
nu3=$((RANDOM%100-100))
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
num = raw_input("請輸入兩個數字，中間以空白隔開：")
num_list = num.split()
x = [int(y) for y in num_list]
def avg1 (x1=100, x2=50):
    if x1>=0 and x2>=0:
        return (x1+x2)/2
    elif x1<0 or x2<0:
        return (100+x1+x2)/3
    
if len(x) == 1:
	tmp=str(avg1(x[0]))
else:
	tmp=str(avg1(x[0],x[1]))
print 'Average='+ tmp
EOF
#echo iiii=$nu1,$nu2,$nu3
echo "$nu1 $nu2" | python /tmp/test > /tmp/$file.ans1
echo "$nu1 $nu3" | python /tmp/test > /tmp/$file.ans2
echo "$nu1" | python /tmp/test > /tmp/$file.ans3
egrep -q 'bin/(python|env)' $file && grep -q '\.split' $file && \
echo "$nu1 $nu2" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans1 /tmp/$file.ttt && \
echo "$nu1 $nu3" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans2 /tmp/$file.ttt && \
echo "$nu1" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans3 /tmp/$file.ttt
print_yn $? $file

wget -qO /tmp/list.txt https://dywang.csie.cyut.edu.tw/list.txt
nu=$((RANDOM%20+1))
list4=$(grep list4 /tmp/list.txt)
file='fun-var-len1.py'
nu1=$((RANDOM%7+1))
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
$list4
nu = int(raw_input("請輸入一個數字："))
def varlen (num, *inlist4):
	sum=0
	for i in range(0,num):
		sum += inlist4[i]
	return sum/num
avg=varlen(nu,*list4)
print 'Average='+ str(avg)
EOF
#echo iiii=$nu1,$nu2,$nu3
echo "$nu1" | python /tmp/test > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q 'list4' $file && \
echo "$nu1" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file


file='fun-lambda1.py'
nu1=$((RANDOM%100-50))
nu2=$((RANDOM%100-50))
nu3=$((RANDOM%100-50))
cat > /tmp/test << EOF
#!/usr/bin/python
#coding:utf-8
num = raw_input("請輸入三個數字，中間以空白隔開：")
num_list = num.split()
x,y,z = map(int, num_list)
xyz = lambda x, y, z : x+y-2*z
strtmp=str(xyz(x,y,z))
print 'x+y-2*z='+strtmp
EOF
#echo iiii=$nu1,$nu2,$nu3
echo "$nu1 $nu2 $nu3" | python /tmp/test > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q '\.split' $file && \
grep -q 'map' $file && grep -q 'lambda' $file && \
echo "$nu1 $nu2 $nu3" | ./$file > /tmp/$file.ttt && \
diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file

file='moduleself1.py'
nu1=$((RANDOM%100+1))
nu2=$((RANDOM%100+1))
nu3=$((RANDOM%100-150))
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import moduleself1 as m1
print m1.avg1(),m1.sum1(),m1.avg1($nu1,$nu2),m1.avg1($nu2,$nu3),m1.sum1($nu1,$nu2),m1.sum1($nu2,$nu3)
a1=($nu1+$nu2)/2
a2=(100+$nu2+$nu3)/3
s1=$nu1+$nu2
s2=100+$nu2+$nu3
print "75 200",str(a1),str(a2),str(s1),str(s2)
EOF
#echo iiii=$nu1,$nu2,$nu3
#python test
test "$(python test | uniq -cd | wc -l)" -eq 1
print_yn $? $file


file='module-importself1.py'
nu1=$((RANDOM%100))
nu2=$((nu1+nu1%2))
nu3=$((nu1+nu1%2+1))
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import moduleself1 as m1
num = int(raw_input("請輸入一數字"))
if num%2 == 0:
	avg=m1.avg1(x1=num)
	sum=m1.sum1(x2=num)
else:
	avg=m1.avg1(x2=num)
	sum=m1.sum1(x1=num)
print "Input=%d Average=%d Sum=%d" % (num, avg, sum)
EOF
echo "$nu2" | python test > /tmp/$file.ans2
echo "$nu3" | python test > /tmp/$file.ans3
egrep -q 'bin/(python|env)' $file && grep -q 'import moduleself1' $file && \
echo "$nu2" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans2 /tmp/$file.ttt && \
echo "$nu3" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans3 /tmp/$file.ttt 
print_yn $? $file


file='module-importself2.py'
nu1=$((RANDOM%100))
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
from moduleself1 import avg1 as ms1avg
num = int(raw_input("請輸入一數字"))
avg=ms1avg(x1=num)
print "Input=%d Average=%d" % (num, avg)
EOF
echo "$nu1" | python test > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && \
egrep -q '^from +moduleself1 +import +avg1 +as +ms1avg' $file && \
echo "$nu1" | ./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file


file='module-sys1.py'
nu1=$((RANDOM%100))
nu2=$((RANDOM%100))
rstr1=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import sys
intsum=0
count=0
strsum=''
for i in sys.argv[1:]:
	if unicode(i).isnumeric():
		intsum+=int(i)
		count+=1
	else:
		strsum+=i
intsum/=count
print "%s=%d" % (strsum, intsum)
EOF
python test $nu1 asd 723 $rstr1 932 zxc $nu2 > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && \
./$file $nu1 asd 723 $rstr1 932 zxc $nu2 > /tmp/$file.ttt && \
diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file

file='file-write1.py'
rstr1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)
egrep -q 'bin/(python|env)' $file && grep -q '\.close()' $file && \
./$file $rstr1 && diff -q /home/dywang/sid $rstr1 
print_yn $? $file
rm -f $rstr1

file='file-read-write1.py'
nu1=$((RANDOM%100+10))
nu2=$((RANDOM%100+10))
rstr1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)
dd skip=$nu1 count=$nu2 if=/usr/bin/yes of=/tmp/$file.ans bs=1 >/dev/null 2>&1
egrep -q 'bin/(python|env)' $file && grep -q '\.close()' $file && \
./$file $rstr1 $nu1 $nu2 && diff -q $rstr1 /tmp/$file.ans
print_yn $? $file
rm -f $rstr1


file='try-except-else1.py'
rstr1=$(cat /dev/urandom | tr -dc 'a-d' | fold -w 1 | head -n 1)
rstr2=$(cat /dev/urandom | tr -dc 'e-z' | fold -w 2 | head -n 1)
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import sys
dict1 = {'a':1,'b':2,'c':3,'d':4}
try:
    dict1[sys.argv[1]]
except KeyError:
    print sys.argv[1],"不存在"
else:
    del dict1[sys.argv[1]]
    print dict1
EOF
python test $rstr1 > /tmp/$file.ans1
python test $rstr2 > /tmp/$file.ans2
egrep -q 'bin/(python|env)' $file && grep -q '^except KeyError:' $file && \
./$file $rstr1 > /tmp/$file.ttt && diff -q /tmp/$file.ans1 /tmp/$file.ttt && \
./$file $rstr2 > /tmp/$file.ttt && diff -q /tmp/$file.ans2 /tmp/$file.ttt 
print_yn $? $file


file='try-except-else2.py'
rstr1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)
cp /etc/man.config /tmp/abc.ans
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import sys
try:
	fo = open(sys.argv[1], "r")
	data = fo.read()
except IOError:
	fo = open("/tmp/$rstr1.ttt", "w")
	fo.write("新建立的檔案 "+ sys.argv[1]+"\n")
else:
	wordlist = data.split()
	print "檔案", sys.argv[1], "中共有", len(wordlist),"個字"
	fo.close()
EOF
python test $rstr1
python test /tmp/abc.ans > /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q '^except IOError:' $file && \
./$file $rstr1 && diff -q /tmp/$rstr1.ttt $rstr1 && \
./$file /tmp/abc.ans > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file
rm -f $rstr1

file='try-except-finally1.py'
rstr1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)
nu1=$((RANDOM%50+10))
nu2=$((RANDOM%50-50))
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import sys
class NotPositiveError(UserWarning):
    def __init__(self,err='Not a positive number'):
        Exception.__init__(self,err)
try:
    age = int(sys.argv[1])
    if age <= 0:
        raise NotPositiveError
except IndexError as e:
    print "你沒輸入年齡",e
except ValueError as e:
    print "你輸入的年齡不是數字",e
except NotPositiveError as e:
    print "你輸入的年齡是負數或 0",e
else:
    print "你的年齡是",age
finally:
    print "程式結束"
EOF
python test $rstr1 > /tmp/$file.ans1
python test $nu1 > /tmp/$file.ans2
python test $nu2 > /tmp/$file.ans3
python test  > /tmp/$file.ans4
egrep -q 'bin/(python|env)' $file && grep -q 'NotPositiveError' $file && \
./$file $rstr1 > /tmp/$file.ttt && diff -q /tmp/$file.ans1 /tmp/$file.ttt && \
./$file $nu1 > /tmp/$file.ttt && diff -q /tmp/$file.ans2 /tmp/$file.ttt && \
./$file $nu2 > /tmp/$file.ttt && diff -q /tmp/$file.ans3 /tmp/$file.ttt && \
./$file > /tmp/$file.ttt && diff -q /tmp/$file.ans4 /tmp/$file.ttt 
print_yn $? $file

file='re-match1.py'
rstr1=H$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)d
rstr2=$(cat /dev/urandom | tr -dc 'i-zI-Z' | fold -w 6 | head -n 1)
cp /etc/man.config /tmp/abc.ans
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import re, sys

str1 = sys.argv[1]
mo1 = re.match( r'h.*d', str1, re.I)
if mo1: 
	print mo1.group()
else: 
	print "找不到字串", str1
EOF
egrep -q 'bin/(python|env)' $file && grep -q 're\.match' $file && \
test "$(./$file $rstr1)" == "$(python test $rstr1)" && \
test "$(./$file $rstr2)" == "$(python test $rstr2)"
print_yn $? $file

file='re-search1.py'
rstr1=H$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 6 | head -n 1)d
rstr2=$(cat /dev/urandom | tr -dc 'i-zI-Z' | fold -w 6 | head -n 1)
cp /etc/man.config /tmp/abc.ans
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import re, sys

str1 = sys.argv[1]
mo1 = re.search( r'^h.*d$', str1, re.I)
if mo1: 
	print mo1.group()
else: 
	print "找不到字串", str1
EOF
egrep -q 'bin/(python|env)' $file && grep -q 're\.search' $file && \
test "$(./$file $rstr1)" == "$(python test $rstr1)" && \
test "$(./$file $rstr2)" == "$(python test $rstr2)"
print_yn $? $file

file='re-sub1.py'
rstr1=$(cat /dev/urandom | tr -dc '()[]{}' | fold -w 10 | head -n 1)
rstr2=$(cat /dev/urandom | tr -dc '([{' | fold -w 5 | head -n 1)
str2=''
rnu=$((RANDOM%8))
rstr3=$(cat /dev/urandom | tr -dc '([{' | fold -w 1 | head -n 1)
for i in $(echo $rstr2| sed 's/\(.\)/\1 /g'); do
    if [ "$i" == "{" ]; then
        str2="}"$str2
    elif [ "$i" == "[" ]; then
        str2="]"$str2
    elif [ "$i" == "(" ]; then
        str2=")"$str2
    fi
done
rnu1=$((RANDOM%3))
if [ "$rnu1" -eq "0" ]; then 
	str3='()'
elif [ "$rnu1" -eq "1" ]; then 
	str3='[]'
else
	str3='{}'
fi
rstr2=${rstr2}${str2}
rstr2=${rstr2:0:$rnu}"$str3"${rstr2:$rnu}
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import re, sys
ans = sys.argv[1]
print ans
tmp=''
while ans!=tmp:
	tmp=ans
	ans=re.sub('\(\)','',ans)
	ans=re.sub('{}','',ans)
	ans=re.sub('\[\]','',ans)
	if (ans != '' and ans == tmp ): 
		print "Ans=ERROR"
		sys.exit()
print "Ans=CORRECT"
sys.exit()
EOF
egrep -q 'bin/(python|env)' $file && grep -q 're\.sub' $file && \
test "$(./$file $rstr1)" == "$(python test $rstr1)" && \
test "$(./$file $rstr2)" == "$(python test $rstr2)"
print_yn $? $file

file='re-sub2.py'
rstr1=$(cat /dev/urandom | tr -dc 'AaLl\ m-qM-R' | fold -w 60 | head -n 1)
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import re, sys
ans = sys.argv[1]
print ans
tmp=""
while ans!=tmp:
    tmp=ans
    ans=re.sub('[aA][^aAlL]*[lL]','',ans)
print ans
sys.exit()
EOF
python test "$rstr1"> /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q 're\.sub' $file && \
./$file "$rstr1" > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file


file='re-sub3.py'
rstr1=$(cat /dev/urandom | tr -dc 'A-E\ m-q0-9' | fold -w 60 | head -n 1)
cat > test << EOF
#!/usr/bin/python
#coding:utf-8
import re, sys
ans = sys.argv[1]
print ans
ans=re.sub('[A-Za-z]+',' ',ans)
ans=re.sub('\s+','+',ans)
ans=re.sub('^\+','',ans)
ans=re.sub('\+$','',ans)
print "%s=%d" % (ans,eval(ans))
sys.exit()
EOF
python test "$rstr1"> /tmp/$file.ans
egrep -q 'bin/(python|env)' $file && grep -q 're\.sub' $file && \
./$file "$rstr1" > /tmp/$file.ttt && diff -q /tmp/$file.ans /tmp/$file.ttt 
print_yn $? $file

#echo $rstr1
#rm -f *.pyc
#rm -f {/tmp/,}test
#rm -f /tmp/*.{ans,ttt}{1,2,3,}
chown dywang.dywang -R /home/dywang/zzz
exit


