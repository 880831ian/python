today=`date +%Y%m%d`
nowtime=`date +%T`
sid=`ifconfig eth1 | grep 'inet ' | sed 's/.*addr:192.168.1.//' | sed 's/ .*//'`
a="\e[32m";b="\e[0m";c="\e[31m";d="\e[34m"
x="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
y="━━━━━━━━━━━━━━━━━以下錯誤輸出━━━━━━━━━━━━━━━━━━━"
z="━━━━━━━━━━━━━━━━━以上錯誤輸出━━━━━━━━━━━━━━━━━━━"
echo -e ${d}${x}${b};
echo "            Find python log "
echo "執行日期：${today} 執行時間：${nowtime}"
echo -e "${a}學號姓名檔案from /home/dywang/sid${b}"
cat ../sid
echo -e ${d}${y}${b};
cat /tmp/e517python_$sid.log | grep ':1'
if [ "$?" = "1" ];then
echo -e "${c}無錯誤！${b}"
fi
echo -e ${d}${z}${b};

