[ -n "$1" ] && touch $1 || exit 0
echo $?

