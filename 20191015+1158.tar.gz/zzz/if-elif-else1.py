#!/usr/bin/env python
# coding: utf-8

var = raw_input("請輸入一字元")
#num = int(var)
if var == 'D':
	print ("%c = D" % var)
elif var < 'D':
	print("%c < D" % var)
else:
	print("%c > D" % var)

