#!/bin/bash

action=$(basename $0)
action=${action%.sh}
laction=/tmp/${action%network}local.sh
kvm=kvm6.deyu.wang
kvmpw=123qweasd
source /tmp/printyn.sh

#declare -i number=$RANDOM*4/32767+5
cd ~dywang/zzz || exit
mysid=$(cat /home/dywang/sid)
for i in 1 2 3; do
	test -f vi$i.txt && diff -quN /tmp/vi$i vi$i.txt
	print_yn $? vi$i
done
#rm -f /tmp/vi*

file=gcc1
if [ -f $file.c ]; then
	gcc -o /tmp/$file.o -c $file.c && diff -q /tmp/$file.o $file.o
	print_yn $? $file.o
	[ -f $file.b1 ] && gcc -o /tmp/$file $file.c && \
	diff -q /tmp/$file $file.b1 && \
	[ "$(./$file.b1)" == "$mysid" ]
	print_yn $? $file.b1
	[ -f $file.b2 ] && gcc -lm -o /tmp/$file $file.c && \
	diff -q /tmp/$file $file.b2 && \
	[ "$(./$file.b2)" == "$mysid" ]
	print_yn $? $file.b2
else
	print_yn none $file.o
	print_yn none $file.b1
	print_yn none $file.b2
fi

file=make1
if [ -d $file ]; then
	cd $file
	( cd /tmp
	wget -qO $file.tar.gz $download/$file.tar.gz
	tar zxf $file.tar.gz
	cd $file
	sed -i "s/^\(printf(\"\).*\(\")\;\)/\1$mysid\\\n\2/g" 2.c
	gcc -c main.c
	gcc -c 2.c
	gcc -c 3.c
	)
	diff -q /tmp/$file/main.o main.o
	print_yn $? main.o
	diff -q /tmp/$file/2.o 2.o
	print_yn $? 2.o
	diff -q /tmp/$file/3.o 3.o
	print_yn $? 3.o
	test  -f main.b1
	print_yn $? main.b1
	test "$(./main.b1)" == "$mysid"
	print_yn $? main.b1.sid
	cd ..
	chmod 500 /tmp/make1
else
	print_yn none main.o
	print_yn none 2.o
	print_yn none 3.o
	print_yn none main.b1
	print_yn none main.b1.sid
fi

file=cbase1
if [ -d $file ]; then
	cd $file
	( cd /tmp
	wget -qO $file.tar.gz $download/$file.tar.gz
	tar zxf $file.tar.gz
	cd $file
	sed -i 's/$/;/' token1
	grep '^[a-zA-Z_]' identifier1 | grep -v '[@$+-]' > identmp
	mv -f identmp identifier1
	sed -i 's/A/a/' identifier2
	sed -i -r '/(cases|continus|enmu|dhcp|cher)/d' keyword1
	sed -i -e 's/volatil/volatile/' -e 's/regiter/register/' keyword2
	sed -i 's/f\[/f(/' debug1.c
	gcc -o debug1 debug1.c
	sed -i 's/C/c/' debug2.c
	gcc -o debug2 debug2.c
	sed -i 's/+c/+b/' debug3.c
	gcc -o debug3 debug3.c
	)
	for file in token1 identifier1 identifier2 keyword1 keyword2; do
		diff -q /tmp/cbase1/$file $file
		print_yn $? $file
	done
	for file in debug1 debug2 debug3; do
		diff -q /tmp/cbase1/$file.c $file.c
		print_yn $? $file.c
		diff -q /tmp/cbase1/$file $file
		print_yn $? $file
	done
	cd ..
	chmod 500 /tmp/cbase1
else
	for file in token1 identifier1 identifier2 keyword1 keyword2; do
		print_yn none $file
	done
	for file in debug1 debug2 debug3; do
		print_yn none $file.c
		print_yn none $file
	done
fi
#w4-2693
#w2-2741


file=dtype1
grep -q 'sizeof.*unsigned short' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f $file ] && ./$file | grep -q '^unsigned short 2'$'\t'"$mysid"
print_yn $? $file

file=dtype2
sed 's/ //g' $file.c | grep -q 'short[ab]' && \
sed 's/ //g' $file.c | grep -q 'b=a+800;' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f $file ] && ./$file | grep -q "^32000 + 800 = -32736$"
print_yn $? $file

file=dtype3
grep -qE "^\s*char\s+ch\s*=\s*'#';" $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f $file ] && ./$file | grep -q '^ASCII of # = 35$' && ./$file | grep -q '^ASCII 35 = #$'
print_yn $? $file

file=dtype4
grep -q '^\s*printf\s*(\s*"%c%c%c%c%c%c"' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f $file ] && ./$file | grep -q ^4$'\t'g$'\t'4$
print_yn $? $file

file=dtype5
sed 's/\s//g' $file.c | grep -q '^\s*b=(int)a+800;$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f $file ] && ./$file | grep -q "^32000 + 800 = 32800$"
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*
exit

if false; then  ##################IF#######################################

fi   ##########################FI#########################

file=getput1
grep -q '^\s*printf\s*(\s*"輸入一字元："' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rstr=$(cat /dev/urandom | tr -dc 'a-z' | fold -w 1 | head -n 1)
[ -f $file ] && echo $rstr | ./$file | grep -q ^輸入一字元：輸入的字元：$rstr
print_yn $? $file

file=getput2
grep -q '^\s*printf\s*(\s*"輸入一字串："' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rstr=$(cat /dev/urandom | tr -dc 'a-z\ ' | fold -w 10 | head -n 1)
[ -f $file ] && echo "$rstr" | ./$file | grep -q "^輸入一字串：輸入的字串：$rstr"
print_yn $? $file

file=getput3
grep -q '^\s*fgets\s*(.*stdin' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rstr=$(cat /dev/urandom | tr -dc 'a-z ' | fold -w 10 | head -n 1)
rc=$(cat /dev/urandom | tr -dc 'A-Z ' | fold -w 1 | head -n 1)
echo -e "輸入一字串：輸入的字串：$rstr\n\n輸入一字元：輸入的字元：$rc" > /tmp/$file
[ -f $file ] && echo -e "$rstr\n$rc" | ./$file > /tmp/$file.1
diff -q /tmp/$file /tmp/$file.1
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*


file=formatio1
grep -q '^\s*fgets\s*(.*stdin' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rnu=$((RANDOM%20+10))
rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rnu | head -n 1)
[ -f $file ] && echo $rstr | ./$file | grep -q "$((rnu+1)) \"$rstr\""
print_yn $? $file

file=formatio2
grep -q '^\s*printf\s*(.*%08.2f\\n' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%100+50)).$((RANDOM%90+10))
num=$(printf "%08.2f\n" $rn1) ##212.345 212.35
#echo cccc=$rn1,$num
[ -f $file ] && echo ${rn1}$((RANDOM%300+100)) | ./$file | grep -q "num=$num"
print_yn $? $file

file=formatio3
grep -q '^\s*printf\s*(\s*\"192.168.1.%s' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rs1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 8 | head -n 1)
rs2=$(cat /dev/urandom | tr -dc '0-9' | fold -w 8 | head -n 1)
rnu=$((RANDOM%150+50))
[ -f $file ] && echo "$rs1 $rs2 $rnu" | ./$file | grep -q "輸入：姓名 學號 IP末段：192.168.1.$rnu,$rs2,$rs1"
print_yn $? $file

file=formatio4
grep -q '^\s*scanf\s*(\s*\"%d%c%c%d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rs1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 1 | head -n 1)
rs2=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 1 | head -n 1)
rn1=$((RANDOM%100-50))
rn2=$((RANDOM%100-100))
rn3=$((rn1+rn2))
[ -f $file ] && echo "${rn1}${rs1}${rs2}${rn2}" | ./$file | grep -q "$rs2-$rs1 : $rn1 + $rn2 = $rn3"
print_yn $? $file

file=formatio5
grep -q '^\s*scanf\s*(\s*\"%d%\[^0-9-\]%d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rnu=$((RANDOM%10+3))
rs1=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rnu | head -n 1)
rn1=$((RANDOM%100-50))
rn2=$((RANDOM%100-100))
rn3=$((rn1+rn2))
[ -f $file ] && echo "${rn1}${rs1}${rn2}" | ./$file | \
grep -q "$rs1 : $rn1 + $rn2 = $rn3"
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*

file=operator1
grep -q '^\s*printf\s*(\s*\"%d -- %d -- %d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rnu=$((RANDOM%50))
[ -f $file ] && echo $rnu | ./$file | \
grep -q "$rnu -- $((rnu*9/5+32)) -- $((rnu%7))"
print_yn $? $file

file=operator2
grep -q '^\s*printf\s*(\s*\"%d mi = %.2f km' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rnu=$((RANDOM%500))
rnu=190
km=$(echo $rnu*1.609344 | bc | sed 's/\([0-9]*\)\.\([0-9]\).*$/\1\\.\2[0-9]/')
#echo kkkkk=$rnu,$km
[ -f $file ] && echo $rnu | ./$file | grep -q "$rnu mi = $km km"
print_yn $? $file

file=operator3
grep -q '^\s*printf\s*(\s*\"a %c b = %d %c %d = %d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rs1=$(cat /dev/urandom | tr -dc '*' | fold -w 1 | head -n 1)
rn1=$((RANDOM%500))
rn2=$((RANDOM%20-100))
num=$((rn1${rs1}rn2))
#echo cccc=$rs1,$rn1,$rn2,$num
[ -f $file ] && [[ "$(echo "${rn1}${rs1}${rn2}" | ./$file)" =~ "a $rs1 b = $rn1 $rs1 $rn2 = $num"$ ]]
print_yn $? $file

file=operator4
grep -q '^\s*printf\s*(\s*\"a %c b = %d %c %d = %d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rs1=$(cat /dev/urandom | tr -dc '+-' | fold -w 1 | head -n 1)
rn1=$((RANDOM%500))
rn2=$((RANDOM%20-100))
num=$((rn1${rs1}rn2))
[ "$rs1" == '+' ] && rs2='-' || rs2='+'
rn3=$((0-rn2))
[ -f $file ] && [[ "$(echo "${rn1}${rs1}${rn2}" | ./$file)" =~ "a $rs1 b = $rn1 $rs2 $rn3 = $num"$ ]]
print_yn $? $file

file=operator5
grep -q '^\s*printf\s*(\s*\"%d >> 1 = %d, %d << 2 = %d' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%500))
rn2=$((RANDOM%100))
cat > /tmp/$file.ans << EOF
$rn1 & $rn2 = $((rn1&rn2))
$rn1 | $rn2 = $((rn1|rn2))
$rn1 ^ $rn2 = $((rn1^rn2))
~$rn1 = $((~rn1)), ~$rn2 = $((~rn2))
$rn1 >> 1 = $((rn1>>1)), $rn2 << 2 = $((rn2<<2))
EOF
[ -f $file ] && echo "${rn1} ${rn2}" | ./$file | grep -o "~*$rn1.*$" > /tmp/$file.ttt
diff -q /tmp/$file.ans /tmp/$file.ttt
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*

file=choice1
sed 's/\s//g' $file.c | grep -q '^if((a%2).*&&(b%2)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%500+100))
rn2=$((RANDOM%100-500))
test $((rn1%2)) -ne 0 && ((rn1++))
test $((rn2%2)) -eq 0 && ((rn2++))
num1=$((rn1+rn2))
rn3=$((rn1+1))
num2=$((rn3-rn2))
#echo cccc=$rn1,$rn2,$num1,$rn3,$rn4,$num2
[ -f $file ] && [[ "$(echo "$rn1 $rn2" | ./$file)" =~ "$rn1 + $rn2 = $num1"$ ]]\
&& [[ "$(echo "$rn3 $rn2" | ./$file)" =~ "$rn3 - $rn2 = $num2"$ ]]
print_yn $? $file

file=choice2
sed 's/\s//g' $file.c | grep -q '^if((a%2).*&&(b%2)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%500+100))
rn2=$((RANDOM%100-500))
test $((rn1%2)) -eq 0 && ((rn1++))
test $((rn2%2)) -ne 0 && ((rn2++))
num1=$((rn1^rn2))
rn3=$((rn1+1))
num2=$((rn3&rn2))
#echo cccc=$rn1,$rn2,$num1,$rn3,$num2
[ -f $file ] && [[ "$(echo "$rn1 $rn2" | ./$file)" =~ "$rn1 ^ $rn2 = $num1"$ ]]\
&& [[ "$(echo "$rn3 $rn2" | ./$file)" =~ "$rn3 & $rn2 = $num2"$ ]]
print_yn $? $file

file=choice3
grep -B2 '^\s*printf\s*(\s*\"%d : NOT the month' $file.c | \
grep -q '^\s*else\s*{*\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
month=(Spring Summer Autumn Winter)
rn1=$((RANDOM%12+1))
test $rn1 -le 2 && mi=3 || mi=$((rn1/3-1))
rn2=$((RANDOM%10-11))
#echo cccc=$rn1,$rn2,$mi,${month[$mi]},$mi
[ -f $file ] && [[ "$(echo "$rn1" | ./$file)" =~ "$rn1 : ${month[$mi]}"$ ]] && \
[[ "$(echo "$rn2" | ./$file)" =~ "$rn2 : NOT the month"$ ]]
print_yn $? $file

file=choice4
cat $file.c | tr '\n' ' ' | sed 's/\s//g' | grep -q ';((a%2).*&&(b%2).*)?printf(\"%d+%d=%d\\n\",.,.,.+.):printf(\"%d-%d=%d\\n\",.,.,.-.);' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%500+100))
rn2=$((RANDOM%100-500))
test $((rn1%2)) -ne 0 && ((rn1++))
test $((rn2%2)) -eq 0 && ((rn2++))
num1=$((rn1+rn2))
rn3=$((rn1+1))
num2=$((rn3-rn2))
#echo cccc=$rn1,$rn2,$num1,$rn3,$rn4,$num2
[ -f $file ] && [[ "$(echo "$rn1 $rn2" | ./$file)" =~ "$rn1 + $rn2 = $num1"$ ]]\
&& [[ "$(echo "$rn3 $rn2" | ./$file)" =~ "$rn3 - $rn2 = $num2"$ ]]
print_yn $? $file

file=choice5
cat $file.c | tr '\n' ' ' | sed 's/\s//g' | grep -q ';((a%2).*&&(b%2).*)?printf(\"%d^%d=%d\\n\",.,.,.^.):printf(\"%d&%d=%d\\n\",.,.,.&.);' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%500+100))
rn2=$((RANDOM%100-500))
test $((rn1%2)) -eq 0 && ((rn1++))
test $((rn2%2)) -ne 0 && ((rn2++))
num1=$((rn1^rn2))
rn3=$((rn1+1))
num2=$((rn3&rn2))
#echo cccc=$rn1,$rn2,$num1,$rn3,$num2
[ -f $file ] && [[ "$(echo "$rn1 $rn2" | ./$file)" =~ "$rn1 ^ $rn2 = $num1"$ ]]\
&& [[ "$(echo "$rn3 $rn2" | ./$file)" =~ "$rn3 & $rn2 = $num2"$ ]]
print_yn $? $file

file=choice6
grep -B1 '^\s*printf\s*(\s*\"%d : NOT the month' $file.c | \
grep -q '^\s*default\s*:\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
month=(Spring Summer Autumn Winter)
rn1=$((RANDOM%12+1))
test $rn1 -le 2 && mi=3 || mi=$((rn1/3-1))
rn2=$((RANDOM%10-11))
#echo cccc=$rn1,$rn2,$mi,${month[$mi]},$mi
[ -f $file ] && [[ "$(echo "$rn1" | ./$file)" =~ "$rn1 : ${month[$mi]}"$ ]] && \
[[ "$(echo "$rn2" | ./$file)" =~ "$rn2 : NOT the month"$ ]]
print_yn $? $file

file=choice7
grep -A7 '^\s*STARTADD\s*:\s*' $file.c | \
grep -q '^\s*goto\s*STARTADD\s*;' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%5-5))
rn2=$((RANDOM%10+rn1))
sum=$rn1
str=$(for((i=rn1;i<rn2;i++)); do echo -e "$i+\c"; done)
for((i=rn1+1;i<=rn2;i++)); do ((sum+=i)); done
str="${str}${rn2}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str
[ -f $file ] && [[ "$(echo "$rn1 $rn2" | ./$file)" =~ "$str"$ ]]
print_yn $? $file

file=choice8
grep -q '(\s*a\s*>\s*b\s*)' $file.c && \
grep -A7 '^\s*STARTADD\s*:\s*' $file.c | \
grep -q '^\s*goto\s*STARTADD\s*;' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%5-5))
rn2=$((RANDOM%10+rn1))
sum=$rn1
str=$(for((i=rn1;i<rn2;i++)); do echo -e "$i+\c"; done)
for((i=rn1+1;i<=rn2;i++)); do ((sum+=i)); done
str="${str}${rn2}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str
[ -f $file ] && [[ "$(echo "$rn2 $rn1" | ./$file)" =~ "$str"$ ]]
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*

file=loop1
grep -q '^\s*for' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
str1=$(for((i=1;i<20;i++)); do echo -e "$i+\c"; done)
for((i=1,sum1=0;i<21;i++)); do ((sum1+=i)); done
str1="${str1}20=$sum1"
rn1=$((RANDOM%5+2))
rn2=$((RANDOM%5+rn1+3))
sum=$rn1
str=$(for((i=rn1;i<rn2;i++)); do echo -e "$i+\c"; done)
for((i=rn1+1;i<=rn2;i++)); do ((sum+=i)); done
str="${str}${rn2}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str,$str1,$sum1
[ -f $file ] && [[ "$(echo "$rn2 $rn1" | ./$file)" =~ "$str"$ ]] \
&& [[ "$(echo "-14 -3" | ./$file)" =~ "$str1"$ ]]
print_yn $? $file

file=loop2
sed 's/\s//g' $file.c | grep -q '^while((.%2)==0||(.[><][0-9]' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%5+12))
sum=0
test $((rn1%2)) -eq 0 && ((rn1+=1)) 
str=$(for i in `seq 1 2 $rn1`; do echo -e "$i+\c"; done)
for i in `seq 1 2 $rn1`; do ((sum+=i)); done
str="${str%+}=$sum"
#echo cccc=$rn1,$sum,$str
[ -f $file ] && [[ "$(echo "-1 23 12 $rn1" | ./$file)" =~ "$str"$ ]]
print_yn $? $file

file=loop3
cat $file.c | tr '\n' ' ' | sed 's/\s//g' | grep -q 'do{.*}while((.%2).=[01]||(.[><][0-9]' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%20+10))
sum=0
test $((rn1%2)) -eq 1 && ((rn1+=1)) 
str=$(for i in `seq 2 2 $rn1`; do echo -e "$i+\c"; done)
for i in `seq 2 2 $rn1`; do ((sum+=i)); done
str="${str%+}=$sum"
#echo cccc=$rn1,$sum,$str
[ -f $file ] && [[ "$(echo "-1 124 13 $rn1" | ./$file)" =~ "$str"$ ]]
print_yn $? $file

file=loop4
cat $file.c | tr '\n' ' ' | sed 's/\s//g' | grep -q 'f(.*>=*3){.*printf("輸入超過3次");return;}' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%20+10))
sum=0
test $((rn1%2)) -eq 1 && ((rn1+=1)) 
str=$(for i in `seq 2 2 $rn1`; do echo -e "$i+\c"; done)
for i in `seq 2 2 $rn1`; do ((sum+=i)); done
str="${str%+}=$sum"
#echo cccc=$rn1,$sum,$str
[ -f $file ] && [[ "$(echo "-1 124 13 $rn1" | ./$file)" =~ "$str"$ ]] \
&& [[ "$(echo "-1 124 13 100" | ./$file)" =~ "輸入超過3次"$ ]]
print_yn $? $file

file=loop5
sed 's/\s//g' $file.c | grep -q "^while(getchar()!='\\\n');$" && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%10+5))
rs=$(cat /dev/urandom | tr -dc 'a-z' | fold -w $rn1 | head -n 1)
#echo cccc=$rn1,$rs
[ -f $file ] && echo -e "A\n${rs}\n" | ./$file | grep -q "\s$rs$"
print_yn $? $file

file=loop6
grep -A1 '^\s*if' $file.c | grep -q 'continue\s*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=0
while [ $((rn1%5)) -eq 0 ]; do
	rn1=$((RANDOM%50+31))
done
sum=0
rn2=$((rn1+5-rn1%5))
str=$(for i in `seq $rn2 5 100`; do echo -e "$i+\c"; done)
for i in `seq $rn2 5 100`; do ((sum+=i)); done
str="${str%+}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str
[ -f $file ] && [[ "$(echo "$rn1" | ./$file)" =~ "$str"$ ]]
print_yn $? $file

file=loop7
grep -A1 '^\s*if.*500' $file.c | grep -q 'break\s*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=0
while [ $((rn1%5)) -eq 0 ]; do
	rn1=$((RANDOM%50+31))
done
sum=0
rn2=$((rn1+5-rn1%5))
for i in `seq $rn2 5 100`; do 
	((sum+=i))
	[[ $sum -gt 500 ]] && iup=$i && break
done
str=$(for i in `seq $rn2 5 $iup`; do echo -e "$i+\c"; done)
str="${str%+}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str
[ -f $file ] && [[ "$(echo "$rn1" | ./$file)" =~ "$str"$ ]] && \
[ -f $file ] && [[ "$(echo 74 | ./$file)" =~ "75+80+85+90+95+100=525"$ ]]
print_yn $? $file

file=loop8
grep -A2 '^\s*for' $file.c | grep -q '^\s*for' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rn1=$((RANDOM%5+3))
for (( i=1; i<=$rn1; i++)); do
	for (( j=1-$rn1; j<$rn1; j++)); do
		if [ $j -lt $i ] && [ $((0-j)) -lt $i ]; then
			echo -e "$i\c"
		else
			echo -e "0\c"
		fi
	done
	echo ''
done > /tmp/$file.ans
[ -f $file ] && echo $rn1 | ./$file | grep -Eo '[0-8]+$' > /tmp/$file.ttt
diff -q /tmp/$file.ttt /tmp/$file.ans
print_yn $? $file

#rm -f /tmp/${file%[0-9]}[0-9]*

file=mfun1
grep -q 'strcat.*argv' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	nstr=''
	for i in `seq $((RANDOM%7+10))`; do
		nstr="$nstr $((RANDOM%100-20))"
	done
	str1='(' ; str2='('
	for i in $nstr; do
		[ $((i%2)) -eq 0 ] && str1="${str1}${i}+" || str2="${str2}${i}+"
	done
	str1="${str1%+})"
	str2="${str2%+})"
	eorate=$(echo "$str1/$str2" | bc -l | xargs printf "%.3f\n")
#echo cccc=$nstr,$str1,$str2,$eorate
	tmp=$(./$file $nstr) && echo "$tmp" | grep -q "$str1/$str2=$eorate"$
	print_yn $? $file
else
	print_yn none $file
fi

file=mfun2
grep -A22 '^int\s\s*main\s*(' $file.c | \
grep -q '^\s*return\s[(\s]*0[\s)]*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%5+2))
	rn2=$((RANDOM%5+7))
	echo "$rn1 $rn2" | ./$file | grep -q CORRECT && \
	echo "$rn2 $rn1" | ./$file | grep -q ERROR && \
	! echo "$rn2 $rn1" | ./$file >/dev/null
	print_yn $? $file
else
	print_yn none $file
fi

file=mfun3
grep -A5 '^\s*switch\s*(\s*errno\s*)' $file.c | grep -q '^\s*case\s\s*EPERM' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
[ -f /tmp/a ] && rm -f /tmp/a
sudo -u dywang touch /tmp/b
if [ $FLAG == 0 ]; then
	sudo -u dywang ./$file mjuyhnbgt b > /tmp/$file.std || [ $? == 2 ] && \
	grep -q '^File renaming error: File not found$' /tmp/$file.std && \
	sudo -u dywang ./$file /tmp/b /root/b > /tmp/$file.std || [ $? == 13 ] && \
	grep -q '^File renaming error: Permission denied$' /tmp/$file.std && \
	sudo -u dywang ./$file /sbin/blkid b > /tmp/$file.std || [ $? == 18 ] && \
	grep -q '^File renaming error: Unknown error$' /tmp/$file.std && \
	sudo -u dywang ./$file /tmp/b /tmp/a | grep -q '/tmp/b renamed to /tmp/a'
	print_yn $? $file
else
	print_yn none $file
fi

file=mfun4
grep -A5 '^\s*switch\s*(\s*errno\s*)' $file.c | grep -A4 '^\s*case\s\s*EPERM' \
| grep -q '^\s*fprintf\s*(\s*stderr\s*,.*)\s*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
sudo -u dywang touch /tmp/b
if [ $FLAG == 0 ]; then
	sudo -u dywang ./$file mjuyhnbgt b 2> /tmp/$file.std || [ $? == 2 ] && \
	grep -q '^File renaming error: File not found$' /tmp/$file.std && \
	sudo -u dywang ./$file /tmp/b /root/b 2> /tmp/$file.std || [ $? == 13 ] &&\
	grep -q '^File renaming error: Permission denied$' /tmp/$file.std && \
	sudo -u dywang ./$file /sbin/blkid b 2> /tmp/$file.std || [ $? == 18 ] && \
	grep -q '^File renaming error: Unknown error$' /tmp/$file.std && \
	sudo -u dywang ./$file /tmp/b /tmp/a | grep -q '/tmp/b renamed to /tmp/a'
	print_yn $? $file
else
	print_yn none $file
fi

file=mfun5
grep -A40 '^#include\s*<unistd.h>' $file.c | grep -A38 'access\s*(\s*argv\[1\]\s*,\s*F_OK' | \
grep -A38 'access\s*(\s*argv\[1\]\s*,\s*R_OK' | grep -A38 'access\s*(\s*argv\[1\]\s*,\s*W_OK' \
| grep -q 'access\s*(\s*argv\[1\]\s*,\s*X_OK' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
#su dywang -c "./$file /tmp/dsf; [ \$? -eq 2 ] && echo \$?"
rm -f /tmp/a /tmp/$file.std 2>/dev/null
if [ $FLAG == 0 ]; then
su dywang -c "cd /home/dywang/zzz; \
	./$file /tmp/a 2>/tmp/$file.std || test \$? -ne 0 && \
	grep -q '^F_OK: No such file or directory$' /tmp/$file.std && touch /tmp/a && \
	./$file /tmp/a 2>/tmp/$file.std || test \$? -ne 0 && \
	grep -q '^X_OK: Permission denied$' /tmp/$file.std && chmod 333 /tmp/a && \
	./$file /tmp/a 2>/tmp/$file.std || test \$? -ne 0 && \
	grep -q '^R_OK: Permission denied$' /tmp/$file.std && chmod 555 /tmp/a && \
	./$file /tmp/a 2>/tmp/$file.std || test \$? -ne 0 && \
	grep -q '^W_OK: Permission denied$' /tmp/$file.std && chmod 777 /tmp/a && \
	./$file /tmp/a | grep -q '^/tmp/a OK$'"

	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

file=func1
grep -q '^int\s\s*sum\s*(\s*int.*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	for((i=1,sum1=0;i<21;i++)); do ((sum1+=i)); done
	str1="1+...+20=$sum1"
	rn1=$((RANDOM%5+2))
	rn2=$((RANDOM%5+rn1+3))
	sum=$rn1
	for((i=rn1+1;i<=rn2;i++)); do ((sum+=i)); done
	str="${rn1}+...+${rn2}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str,$str1,$sum1
	echo "$rn2 $rn1" | ./$file >/dev/null && \
	[[ "$(echo "$rn2 $rn1" | ./$file)" =~ "$str"$ ]] && \
	[[ "$(echo "-14 -3" | ./$file)" =~ "$str1"$ ]]
	print_yn $? $file
else
	print_yn none $file
fi

file=func2
grep -q '^void\s\s*swap\s*(\s*int\s*\*.*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	for((i=1,sum1=0;i<21;i++)); do ((sum1+=i)); done
	str1="1+...+20=$sum1"
	rn1=$((RANDOM%5+2))
	rn2=$((RANDOM%5+rn1+3))
	sum=$rn1
	for((i=rn1+1;i<=rn2;i++)); do ((sum+=i)); done
	str="${rn1}+...+${rn2}=$sum"
#echo cccc=$rn1,$rn2,$sum,$str,$str1,$sum1
	echo "$rn2 $rn1" | ./$file >/dev/null && \
	[[ "$(echo "$rn2 $rn1" | ./$file)" =~ "$str"$ ]] && \
	[[ "$(echo "-14 -3" | ./$file)" =~ "$str1"$ ]]
	print_yn $? $file
else
	print_yn none $file
fi

file=func3
grep -q 'strcat.*argv' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	nstr=''
	for i in `seq $((RANDOM%7+10))`; do
		nstr="$nstr $((RANDOM%100-20))"
	done
	str1='(' ; str2='('
	for i in $nstr; do
		[ $((i%2)) -eq 0 ] && str1="${str1}${i}+" || str2="${str2}${i}+"
	done
	str1="${str1%+})"
	str2="${str2%+})"
	eorate=$(echo "$str1/$str2" | bc -l | xargs printf "%.3f\n")
#echo cccc=$nstr,$str1,$str2,$eorate
	tmp=$(./$file $nstr) && echo "$tmp" | grep -q "$str1/$str2=$eorate"$
	print_yn $? $file
else
	print_yn none $file
fi

file=func4
grep -A100 '^#include\s*<stdarg.h' $file.c | \
grep -q '^int\s\s*sum\s*(\s*int.*\.\.\.\s*)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	nstr=''; sum=0
	rnu=$((RANDOM%3+2))
	for ((i=0; i<rnu; i++)); do
		tmp=$((RANDOM%100-20))
		nstr="$nstr $tmp"
		((sum+=tmp))
	done
	avg=$(echo "scale=4;$sum/$rnu" | bc -l | xargs printf "%.3f\n")
#echo cccc=$nstr,$rnu,$sum,$avg
#nstr=' 9 2 -14'; rnu=3; sum=-3; avg="-1.000"
#cccc= 9 2 -14,3,-3,-1.000
	[ "$sum" -lt "0" ] && sum="\\$sum"
	tmp="$(./$file $nstr)" && echo "$tmp" | grep -q "$sum/$rnu=$avg"$ && \
	./$file $nstr 1 2 3 | grep -q "0/$((rnu+3))=0.000"$ && \
	./$file 3 | grep -q "0/1=0.000"$ 
	print_yn $? $file
else
	print_yn none $file
fi

file=func5
grep -A3 '^#include\s*<stdarg.h' $file.c | \
grep -q '^int\s\s*total\s*=\s*0\s*;\s*$' && \
grep -q '^void\s\s*sum\s*(\s*int.*\.\.\.\s*)' $file.c && \
grep -q '^\s*printf\s*(\s*.*total' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	nstr=''; sum=0
	rnu=$((RANDOM%3+2))
	for ((i=0; i<rnu; i++)); do
		tmp=$((RANDOM%100-120))
		nstr="$nstr $tmp"
		((sum+=tmp))
	done
	avg=$(echo "scale=4;$sum/$rnu" | bc -l | xargs printf "%.3f\n")
#echo cccc=$nstr,$rnu,$sum,$avg
	[ "$sum" -lt "0" ] && sum="\\$sum"
	tmp="$(./$file $nstr)" && echo "$tmp" | grep -q "$sum/$rnu=$avg"$ && \
	./$file $nstr 1 2 3 | grep -q "0/$((rnu+3))=0.000"$ && \
	./$file 3 | grep -q "0/1=0.000"$ 
	print_yn $? $file
else
	print_yn none $file
fi

farr=(
1
1
2
6
24
120
720
5040
40320
362880
3628800
39916800
479001600
6227020800
87178291200
1307674368000
20922789888000
355687428096000
6402373705728000
121645100408832000
2432902008176640000
)

file=func6
sed 's/\s//g' $file.c | grep -C30 '^unsignedlong.*factorial(unsignedlong' | \
grep -A20 '^fprintf(stderr' | grep -q '^printf(\"Factorialof%dis%ld\\n\"' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	nstr=''; sum=0
	rn1=$((RANDOM%20))
	rn2=$((RANDOM%4+1))
	rs1=$(cat /dev/urandom | tr -dc '0-9' | fold -w $rn2 | head -n 1)
	rs2=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w 3 | head -n 1)
#echo cccc=$nstr,$rnu,$sum,$avg
	str1='^-(1), Not a Number!$'
	str2="^${rs2:0:1}($((rn2+1))), Not a Number!$"
	./$file "-$rn1" 2> /tmp/$file.ans || grep -q "$str1" /tmp/$file.ans && \
	./$file "$rs1$rs2" 2> /tmp/$file.ans || grep -q "$str2" /tmp/$file.ans && \
	./$file "$rn1" > /tmp/$file.ans && \
	grep -q "Factorial of $rn1 is ${farr[$rn1]}" /tmp/$file.ans && \
	./$file "$((rn2+20))" > /tmp/$file.ans && \
	grep -q "Factorial of 20 is ${farr[20]}" /tmp/$file.ans
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

wget -q -O /tmp/array.txt $download/array.txt

file=arr1
sed 's/\s//g' $file.c | grep -q 'sizeof(arr1)/sizeof(int);' && \
sed 's/\s//g' $file.c | grep -q '(.*%.*)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr1=($(grep 'arr1\[' /tmp/array.txt | sed 's/.*{//' | sed 's/[,\}]//g'))
	A=${#arr1[@]}
	sum=0; sum1=0; sum2=0
	rnu=$((RANDOM%8+2))
	for ((i=0; i<A; i++)); do
		[ $((i%rnu)) -eq 0 ] && ((sum-=arr1[i])) || ((sum+=arr1[i]))
		[ $((i%2)) -eq 0 ] && ((sum1-=arr1[i])) || ((sum1+=arr1[i]))
		[ $((i%10)) -eq 0 ] && ((sum2-=arr1[i])) || ((sum2+=arr1[i]))
	done
#echo cccc=$nstr,$rnu,$sum,$A
	tmp="$(echo $rnu | ./$file)" && \
	echo "$tmp" | grep -q "A=$A"$'\t'"B=$sum"$ && \
	echo '-2' | ./$file | grep -q "A=$A"$'\t'"B=$sum1"$ && \
	echo '12' | ./$file | grep -q "A=$A"$'\t'"B=$sum2"$ 
	print_yn $? $file
else
	print_yn none $file
fi

file=arr2
grep -Eq '\s*int\s+arr2\[\]\[4\].*;' $file.c && \
grep -q '\s*if\s*(.*>\s*68.*)' $file.c && \
grep -q 'arr2.*65' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr2=$(grep arr2 array.txt | grep -o '\{[0-9, ]*\}' | sed 's/[{},]/ /g')
	letter=(A B C D)
	sum=0; j=0
	rnu=$((RANDOM%4))
	for i in $arr2; do
		[ $((j%4)) -eq $rnu ] && ((sum+=i))
		((j++))
	done
#echo cccc=$rnu,$sum,${letter[$rnu]}
	tmp="$(echo ${letter[$rnu]} | ./$file)" && \
	echo "$tmp" | grep -q "${letter[$rnu]} : $sum"$ && \
	echo u | ./$file | grep -q "Only A B C D"$ 
	print_yn $? $file
else
	print_yn none $file
fi

file=arr3
sed 's/\s//g' $file.c | grep -A10 'strcmp(str1,str2)'| \
grep -C4 'strcat(str1,str2)' | grep -q 'strcat(str2,str1)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%5+4))
	rn2=$((RANDOM%5+4))
	rn3=$((RANDOM%5+11))
	rs1=$(cat /dev/urandom | tr -dc 'a-zP-Z' | fold -w  $rn1 | head -n 1)
	rs2=$(cat /dev/urandom | tr -dc '0-9A-O' | fold -w  $rn2 | head -n 1)
	rs3=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w  $rn3 | head -n 1)
	rstr="$rs1$rs2"
	letter=(A B C D)
	sum=0; j=0
	for i in $arr2; do
		[ $((j%4)) -eq $rnu ] && ((sum+=i))
		((j++))
	done
#echo cccc=$rs1,$rs2,$rs3,$rstr
	tmp="$(echo -e "$rs1\n$rs2" | ./$file)" && \
	echo "$tmp" | grep -q "strcat=$rstr"$ && \
	echo -e "$rs2\n$rs1" | ./$file | grep -q "strcat=$rstr"$ && \
	echo -e "$rs1\n$rs1" | ./$file | grep -q "strcat=$rs1"$ && \
	echo -e "$rs1\n$rs3" | ./$file | grep -q "strlen($rs3) = $rn3 > 10"$
	print_yn $? $file
else
	print_yn none $file
fi

file=arr4
sed 's/\s//g' $file.c | grep -A10 'if(strlen(str1)>21)'| \
egrep -C4 '(str1.*\+32|tolower)' | egrep -q '(str1.*-32|toupper)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%3+4))
	rn2=$((RANDOM%3+4))
	rn3=$((RANDOM%3+4))
	rn4=$((RANDOM%5+22))
	rs1=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w  $rn1 | head -n 1)
	rs2=$(cat /dev/urandom | tr -dc '0-9\ @#%&()_' | fold -w  $rn2 | head -n 1)
	rs3=$(cat /dev/urandom | tr -dc 'a-z' | fold -w  $rn3 | head -n 1)
	rs4=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9\ @#%&()_' | fold -w  $rn4 | head -n 1)
	rstr1="$rs1$rs2$rs3"
	rstr2=$(echo $rs1|tr '[A-Z]' '[a-z]')$rs2$(echo $rs3|tr '[a-z]' '[A-Z]')
#echo cccc=$rstr1,$rstr2,$rn4,$rs4
#echo "$rstr1" | ./$file
#echo "$rs4" | ./$file
	tmp="$(echo "$rstr1" | ./$file)" && \
	echo "$tmp" | grep -q "str1=$rstr1, str2=$rstr2"$ && \
	echo "$rs4" | ./$file | grep -q "strlen($rs4) = $rn4 > 21"$
	print_yn $? $file
else
	print_yn none $file
fi

file=arr5
grep -q '\s*void\s*transform\s*(\s*char\s*\*str1\s*,\s*char\s*\*str2\s*)' $file.c && \
grep -q '^\s*transform\s*(\s*str1\s*,\s*str2\s*)\s*;$' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%3+4))
	rn2=$((RANDOM%3+4))
	rn3=$((RANDOM%3+4))
	rn4=$((RANDOM%5+22))
	rs1=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w  $rn1 | head -n 1)
	rs2=$(cat /dev/urandom | tr -dc '0-9\ @#%&()_' | fold -w  $rn2 | head -n 1)
	rs3=$(cat /dev/urandom | tr -dc 'a-z' | fold -w  $rn3 | head -n 1)
	rs4=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9\ @#%&()_' | fold -w  $rn4 | head -n 1)
	rstr1="$rs1$rs2$rs3"
	rstr2="$(echo $rs1|tr '[A-Z]' '[a-z]')$rs2$(echo $rs3|tr '[a-z]' '[A-Z]')"
#echo cccc=$rstr1,$rstr2,$rn4,$rs4
#cccc=PFQYWH 8401vkfe,pfqywh 8401VKFE,23,qF(N4@q)KdeGuve)iEhukW8
#rstr1="PFQYWH 8401vkfe"; rstr2="pfqywh 8401VKFE"; rn4=23; rs4="qF(N4@q)KdeGuve)iEhukW8"
#echo "$rstr1" | ./$file
#echo "$rs4" | ./$file
	tmp="$(echo "$rstr1" | ./$file)" && \
	echo "$tmp" | grep -q "str1=$rstr1, str2=$rstr2"$ && \
	echo "$rs4" | ./$file | grep -q "strlen($rs4) = $rn4 > 21"$
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

wget -q -O /tmp/array.txt $download/array.txt

file=point1
grep -q '^\s*int\s*arr3\[' $file.c && grep -q '^\s*do\s*{' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr3=($(grep 'arr3\[' /tmp/array.txt | sed 's/.*{//' | sed 's/[,\}]//g'))
	A=${#arr3[@]}
	rnu=$((RANDOM%(A-1)+1))
#echo cccc=${arr3[0]},${arr3[$rnu]},$rnu,$A
	echo -e "-10\n$((A+5))\n$rnu" | ./$file > /tmp/$file.t && \
	grep -q "\*ptr=${arr3[0]}"$'\t'".*"$'\t'"\*(ptr+$rnu)=${arr3[$rnu]}$" /tmp/$file.t && \
	test $(awk -F'=' '{print $2,$4}' /tmp/$file.t | awk '{print ($3-$1)/4}') -eq $rnu
	print_yn $? $file
else
	print_yn none $file
fi

file=point2
grep -q '^\s*char\s*arr8\[' $file.c && grep -q '^\s*do\s*{' $file.c && \
grep -q '^\s*for\s*(\s*ptr.*ptr++\s*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr8=($(grep 'arr8\[' /tmp/array.txt | sed 's/.*{//' | sed 's/[\x27,}]//g'))
	A=${#arr8[@]}
	rnu=$((RANDOM%(A-1)+1))
#echo cccc=$str,$rnu,$A
	str=''
	for((i=rnu;i<A;i++)); do str="$str-${arr8[$i]}-" ; done
#echo cccc=$str,$rnu,$A
	tmp="$( echo -e "-10\n$((A+5))\n$rnu" | ./$file)" && \
	echo "$tmp" | grep -q "String:$str"$
	print_yn $? $file
else
	print_yn none $file
fi

file=point3
grep -q '^\s*char\s*\*name\[\]' $file.c && \
grep -A3 'strlen\s*(\s*name\[' $file.c | \
grep -q '^\s*printf\s*(\s*.*toupper.*)\s*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr11=($(grep arr11 array.txt | sed 's/.*{//' | sed 's/[",}]//g'))
	A=${#arr11[@]}
	rnu=$((RANDOM%(A-1)+1))
	str='Name'
	for((i=0;i<rnu;i++)); do str="$str:`echo ${arr11[$i]}|tr 'a-z' 'A-Z'`" ; done
#echo cccc=$str,$rnu,$A
	tmp="$( echo -e "-10\n$((A+5))\n$rnu" | ./$file)" && \
	echo "$tmp" | grep -q "$str"$
	print_yn $? $file
else
	print_yn none $file
fi

file=point4
sed 's/\s//g' $file.c | \
grep -q '^printf("x=%d\\t\*ptr=%d\\t\*\*pptr=%d\\n",x,\*ptr,\*\*pptr);$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rnu=$((RANDOM%767+100))
	str="x=$rnu\t\*ptr=$rnu\t\*\*pptr=$rnu"
#echo cccc=$rnu,$str
	tmp="$( echo "$rnu" | ./$file)" && \
	echo "$tmp" | grep -Pq "$str"$ #x=$rnu\t\*ptr=$rnu\t\*\*pptr=$rnu"$
	print_yn $? $file
else
	print_yn none $file
fi

file=point5
grep -q '^\s*int\s*ovdiff\s*(\s*int.*,\s*int\s*\*arr4\s*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	arr4=($(grep arr4 array.txt | sed 's/.*{//' | sed 's/[",}]//g'))
	A=${#arr4[@]}
	rnu=$((RANDOM%(A-1)+1))
	sum1=0; sum2=0
	str='Name'
	for((i=rnu;i<A;i++)); do
		[ $((${arr4[i]}%2)) -eq 0 ] && ((sum1+=${arr4[i]})) || ((sum2+=${arr4[i]}))
	done
	str="x=$rnu$'\t'ovdiff=$((sum1-sum2))"
#echo cccc=$rnu,$str
	tmp="$(echo -e "-2\n100\n$rnu" | ./$file)" && \
	echo "$tmp"  | grep -q x=$rnu$'\t'ovdiff=$((sum1-sum2))$
	print_yn $? $file
else
	print_yn none $file
fi

file=point6
grep -A4 'unsigned\s*long\s*\*\s*getSec\s*(\s*int' $file.c | \
grep -q '^\s*static\s*unsigned\s*long\s*secs\[5\]\s*;\s*$' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rnu=$((RANDOM%5+1))
	rn1=$((RANDOM%5+10))
#echo cccc=$rnu,$str
#cccc=1,x=11$'\t'ovdiff=4026
	tmp=$(echo $rnu | ./$file | grep "sec[0-4]=`date +%s`" | wc -l ) && \
	test $tmp -eq $rnu && \
	test $(echo $rn1 | ./$file | grep "sec[0-4]=`date +%s`" | wc -l ) -eq 5
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

file=mema1
sed 's/\s//g' $file.c | grep -A20 '^name=malloc(strlen(argv\[1\]));'| \
grep -A20 '^desc=malloc(strlen(argv\[2\]));'| \
grep -A20 '^printf(\"Name:%s\\n\",name);'| \
grep -A20 '^printf(\"Desc:%s\\n\",desc);' | \
grep -A20 '^free(name);' | grep -q 'free(desc)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	for i in 1 2 3 4; do
		rn1=$((RANDOM%5+5))
		rs[$i]=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rn1 | head -n 1)
	done
	cat > /tmp/$file.ans << EOF
Name: ${rs[1]} ${rs[2]}
Desc: ${rs[3]} ${rs[4]}
EOF
#echo cccc=${rs[1]},${rs[2]}
#cccc=1,x=11$'\t'ovdiff=4026
	./$file "${rs[1]} ${rs[2]}" "${rs[3]} ${rs[4]}" > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=mema2
sed 's/\s//g' $file.c | grep -A20 '^for(.*argc.*)'| \
grep -A20 '^name=malloc(strlen(argv\[.\]));'| \
grep -A20 '^desc=malloc(strlen(argv\[.+1\]));'| \
grep -A20 '^printf(\"Name:%s\\n\",name);'| \
grep -A20 '^printf(\"Name:%s\\n\",name);'| \
grep -A20 '^printf(\"Desc:%s\\n\",desc);' | \
grep -A20 '^free(name);' | grep -q 'free(desc)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	for i in 1 2 3 4 5 6 7 8; do
		rn1=$((RANDOM%5+5))
		rs[$i]=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rn1 | head -n 1)
	done
	cat > /tmp/$file.ans << EOF
Name: ${rs[1]} ${rs[2]}
Desc: ${rs[3]} ${rs[4]}
Name: ${rs[5]} ${rs[6]}
Desc: ${rs[7]} ${rs[8]}
EOF
#echo cccc=${rs[1]},${rs[2]}
#cccc=1,x=11$'\t'ovdiff=4026
	./$file "${rs[1]} ${rs[2]}" "${rs[3]} ${rs[4]}" \
	"${rs[5]} ${rs[6]}" "${rs[7]} ${rs[8]}" > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

file=fio1
grep -A4 'fopen\s*(\s*argv\[1\]' $file.c | grep -q '^\s*while\s*(\s*fscanf' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rnu=$((RANDOM%5+8))
	echo -e '\c' > /tmp/$file.txt
	for((i=0;i<rnu;i++)); do
		rn1=$((RANDOM%5+3))
		rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rn1 | head -n 1)
		echo -e "$rstr \c" >> /tmp/$file.txt
	done
	echo '' >> /tmp/$file.txt
#cat /tmp/$file.txt
	str=$(tr ' ' '\n' < /tmp/$file.txt | grep ^[A-Z] |tr '\n' ':')
	tmp=$(./$file /tmp/$file.txt) && echo "$tmp" | grep -q "$str"$
	print_yn $? $file
else
	print_yn none $file
fi

file=fio2
grep -A4 'fopen\s*(\s*argv\[2\].*w' $file.c | grep -q '^\s*fprintf\s*(' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
rnu=$((RANDOM%5+8))
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	for((i=0;i<rnu;i++)); do
		rn1=$((RANDOM%5+3))
		rstr=$(cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $rn1 | head -n 1)
		echo -e "$rstr \c" >> /tmp/$file.txt
	done
	echo '' >> /tmp/$file.txt
	rs=$(cat /dev/urandom | tr -dc 'a-z' | fold -w 3 | head -n 1)
#cat /tmp/$file.txt
	echo $(tr ' ' '\n' < /tmp/$file.txt | grep ^[A-Z] |tr '\n' ':') > /tmp/$file.ans
	./$file /tmp/$file.txt /tmp/$file.$rs && \
	diff -q /tmp/$file.ans /tmp/$file.$rs
	print_yn $? $file
else
	print_yn none $file
fi

file=fio3
grep -C5 'atoi\s*(\s*argv\[3\]\s*)' $file.c | grep -q 'atoi\s*(\s*argv\[4\]\s*)' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rnu=$((RANDOM%100+100))
	cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1 > /tmp/$file.r
	rn1=$((RANDOM%40+10))
	rn2=$((RANDOM%40+10))
	rs=$(cat /dev/urandom | tr -dc 'a-z' | fold -w 3 | head -n 1)
#cat /tmp/$file.txt
	echo $(cut -c $((rn1+1))-$((rn1+rn2)) /tmp/$file.r | tr 'A-Z' 'a-z') > /tmp/$file.ans
	./$file /tmp/$file.r /tmp/$file.w $rn1 $rn2 && \
	diff -q /tmp/$file.ans /tmp/$file.w
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

file=strunion1
grep -A4 '^struct\s*student' $file.c | grep -q '^\s*char\s*name\[20\]' && \
grep -q '^\s*printf.*\.name' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	echo -e '\c' > /tmp/$file.ans
	for((i=0; i<RANDOM%3+3; i++)); do
		rnu=$((RANDOM%9+3))
		rs=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1)
		rn1=$((RANDOM%140+12345))
		rn2=$((RANDOM%100))
		echo "$rs $rn1 $rn2" >> /tmp/$file.txt
		echo -e "sid=$rn1\tname=$rs\tscore=$rn2" >> /tmp/$file.ans
	done
	tmp=$(./$file poiuy) || echo "$tmp" | grep -q '^poiuy NOT exist\.$' && \
	./$file /tmp/$file.txt > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=strunion2
grep -A2 '^void\s*printgrade\s*(\s*struct\s*student' $file.c | grep -q '^\s*printf' && \
grep -q '^\s*printgrade\s*(\s*[^&]*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	echo -e '\c' > /tmp/$file.ans
	for((i=0; i<RANDOM%3+3; i++)); do
		rnu=$((RANDOM%9+3))
		rs=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1)
		rn1=$((RANDOM%140+12345))
		rn2=$((RANDOM%100))
		echo "$rs $rn1 $rn2" >> /tmp/$file.txt
		echo -e "sid=$rn1\tname=$rs\tscore=$rn2" >> /tmp/$file.ans
	done
	tmp=$(./$file poiuy) || echo "$tmp" | grep -q '^poiuy NOT exist\.$' && \
	./$file /tmp/$file.txt > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=strunion3
grep -A2 '^void\s*printgrade\s*(\s*struct\s*student\s*\*' $file.c | grep -q '^\s*printf' && \
grep -q '^\s*printgrade\s*(\s*&.*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	echo -e '\c' > /tmp/$file.ans
	for((i=0; i<RANDOM%3+3; i++)); do
		rnu=$((RANDOM%9+3))
		rs=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1)
		rn1=$((RANDOM%140+12345))
		rn2=$((RANDOM%100))
		echo "$rs $rn1 $rn2" >> /tmp/$file.txt
		echo -e "sid=$rn1\tname=$rs\tscore=$rn2" >> /tmp/$file.ans
	done
	tmp=$(./$file poiuy) || echo "$tmp" | grep -q '^poiuy NOT exist\.$' && \
	./$file /tmp/$file.txt > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=strunion4
grep -A4 '^struct\s*student' $file.c | grep -q '^\s*unsigned\s*short\s*score\s*:\s*6\s*;' && \
grep -A2 '^void\s*printgrade\s*(\s*struct\s*student\s*\*' $file.c | grep -q '^\s*printf' && \
grep -q '^\s*printgrade\s*(\s*&.*)' $file.c && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	echo -e '\c' > /tmp/$file.ans
	for((i=0; i<RANDOM%3+3; i++)); do
		rnu=$((RANDOM%9+3))
		rs=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1)
		rn1=$((RANDOM%140+12345))
		rn2=$((RANDOM%64))
		rn3=$((RANDOM%3*64))
		echo "$rs $rn1 $((rn2+rn3))" >> /tmp/$file.txt
		echo -e "sid=$rn1\tname=$rs\tscore=$rn2" >> /tmp/$file.ans
	done
	tmp=$(./$file poiuy) || echo "$tmp" | grep -q '^poiuy NOT exist\.$' && \
	./$file /tmp/$file.txt > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=strunion5
grep -A4 '^union\s*student' $file.c | grep -C2 '^\s*char\s*name\[13\]\s*;' \
| grep -q '^\s*unsigned\s*short\s*score\s*;' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	echo -e '\c' > /tmp/$file.txt
	echo -e '\c' > /tmp/$file.ans
	for((i=0; i<RANDOM%3+3; i++)); do
		rnu=$((RANDOM%9+3))
		rs=$(cat /dev/urandom | tr -dc 'A-Z' | fold -w $rnu | head -n 1)
		rn1=$((RANDOM%140+12345))
		rn2=$((RANDOM%100+32))
		echo "$rs $rn1 $rn2" >> /tmp/$file.txt
		rs=$(printf \\$(printf '%03o' $rn2))
		[ $rn2 -eq 92 ] && rs='\\'
		echo -e "sid=$rn2\tname=$rs\tscore=$rn2" >> /tmp/$file.ans
	done
	echo 'sizeof(student)=16' >> /tmp/$file.ans
	tmp=$(./$file poiuy) || echo "$tmp" | grep -q '^poiuy NOT exist\.$' && \
	./$file /tmp/$file.txt > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

file=prepro1
grep -A1 '^#define\s*happy_for\s*(\s*name\s*)' $file.c | grep -q 'printf\s*(.*#name.*__DATE__\s*)'&& \
grep -A10 '^int\s*main' $file.c | grep -q 'happy_for' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	cat > /tmp/$file.ans << EOF
Happy Father's Day! $(date +"%b %e %Y")
Happy Mother's Day! $(date +"%b %e %Y")
Only 5 8
EOF
	tmp=$(./$file a b) || echo "$tmp" | grep -q '^Only 5 8$' && \
	./$file 8 5 9 > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=prepro2
grep -A1 '^#define\s*tokenpaster\s*(\s*n\s*)' $file.c | grep -q 'printf\s*(.*token.*__DATE__\s*)'&& \
grep -A10 '^int\s*main' $file.c | grep -q 'tokenpaster' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	cat > /tmp/$file.ans << EOF
token1 * 2 = 20 ($(date +"%b %e %Y"))
Only 1 2 3
token3 * 2 = 42 ($(date +"%b %e %Y"))
token2 * 2 = 22 ($(date +"%b %e %Y"))
EOF
	./$file 1 8 3 2 > /tmp/$file.ttt && \
	diff -q /tmp/$file.ans /tmp/$file.ttt
	print_yn $? $file
else
	print_yn none $file
fi

file=prepro3
grep -q '^#define\s*MIN\s*(\s*x\s*,\s*y\s*)' $file.c && \
grep -A3 '^int\s*main' $file.c | grep -q '^\s*int.*token[123]' && \
gcc -o /tmp/$file $file.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%150+50))
	rn2=$((RANDOM%20+25))
	rs=$(cat /dev/urandom | tr -dc 'a-z' | fold -w 2 | head -n 1)
	str1="MIN between $rn1 and $rn2 is $rn2 ($(date +"%b %e %Y"))"
	str2="MIN between $rn2 and $rn1 is $rn2 ($(date +"%b %e %Y"))"
#echo -e "cccc=$str"
	[[ "$(./$file $rn1 $rn2)" =~ ^"$str1"$ ]] && \
	[[ "$(./$file $rn2 $rn1)" =~ ^"$str2"$ ]] && \
	[[ "$(./$file $rn1 $rs)" =~ ^"$rn1 or $rs NOT a number!"$ ]]
	print_yn $? $file
else
	print_yn none $file
fi

file=prepro4
grep -q '^void\s*swap\s*(\s*int\s*\*x\s*,\s*int\s*\*y\s*)\s*;\s*$' swap.h && \
grep -q '^void\s*swap\s*(\s*int\s*\*x\s*,\s*int\s*\*y\s*)' swap.c && \
grep -A15 '^#include\s*\"swap\.h\"\s*$' $file.c | grep -q '^\s*swap\s*(\s*&x\s*,\s*&y\s*)\s*;' && \
gcc -o /tmp/$file $file.c swap.c && diff -q /tmp/$file $file
print_yn $? $file.c
if [ $FLAG == 0 ]; then
	rn1=$((RANDOM%150+50))
	rn2=$((RANDOM%20+25))
	str1="After swap, $rn2 + $rn1*2 = $((rn2+rn1*2)) ($(date +"%b %e %Y"))"
#echo -e "cccc=$str"
	[[ "$(./$file $rn1 $rn2)" =~ ^"$str1"$ ]] && \
	[[ "$(./$file $rn1 $rs)" =~ ^"$rn1 or $rs NOT a number!"$ ]]
	print_yn $? $file
else
	print_yn none $file
fi

#rm -f /tmp/${file%[0-9]}[0-9]*

exit  #####################################
