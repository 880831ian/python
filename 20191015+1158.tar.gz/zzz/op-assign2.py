#!/usr/bin/python
# coding: utf-8
x=8721;y=485;x%=y; print(x)
x//=y; print(x)
