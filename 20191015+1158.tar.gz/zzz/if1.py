#!/usr/bin/env python
# coding: utf-8

var = raw_input("請輸入一字串")
if var:
	print "輸入的字串是："+var
