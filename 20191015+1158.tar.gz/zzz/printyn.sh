download='http://dywang.csie.cyut.edu.tw/dywang/download'
Coff='\e[0m'       # Text Reset
Red='\e[0;31m'
count=0
function print_yn (){
	FLAG=$1
    [ $FLAG != 0 ] && echo -e ${Red}${action}_${count}.$2:$1${Coff} || \
    echo ${action}_${count}.$2:$1
    ((count++))
}
sed -i "/^$kvm.*/d" /root/.ssh/known_hosts 2>/dev/null 
