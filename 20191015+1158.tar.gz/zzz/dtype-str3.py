#!/usr/bin/python
# coding: utf-8
x = 123
y = 456
z = str(x) + str(y)
print(z)

