#!/usr/bin/env python
# coding: utf-8

var = raw_input("請輸入一數字")
num = int(var)
if num >= 1000:
	print ("%d >= 1000" % num)
elif num < 500:
	print("%d < 500" % num)
elif num == 500:
	print("%d = 500" % num)
else:
	print("%d > 500" % num)

