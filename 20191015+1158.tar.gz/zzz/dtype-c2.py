#!/usr/bin/python
# coding: utf-8
x = "G"
y = "9"
print (ord(x),ord(y))

