#!/bin/bash

action=$(basename $0)
action=${action%.sh}
laction=/tmp/${action%network}local.sh
para=/tmp/${action%network}para.sh
kvm=$1
ki=$(echo $kvm | grep -o [357])
k2ip=192.168.122.20$ki
#echo "$action,$laction,$para"
kvmu=kvm${ki}usb
kvmpw=123qwe
[[ "$@" =~ "default" ]] && sed -i 's/^if true/if false/' $para
source /tmp/printyn.sh
echo "kvm=$kvm" >> $para
source $para

host deyu.wang >/dev/null || /root/bin/setdnsmasq.sh start >/dev/null
#sshpass -pqweqwe ssh -q -o StrictHostKeyChecking=no deyu1@${kvm} "exit" && sshpass -pqweqwe ssh -o StrictHostKeyChecking=no deyu2@${kvm} "exit" 
#echo ${action}1.user:$?
egrep "$kvmu (`date +%F`|`date -d +1day +%F`)" /root/kvmreverted | tail -1
#sshpass -p$kvmpw ssh -q -o StrictHostKeyChecking=no $kvm 'bash -s' < $laction - $@ 
#rm -f /root/.ssh/known_hosts
#sshpass -p$kvmpw ssh -q -o StrictHostKeyChecking=no $kvm hostname
#print_yn $? passwd
#exit
 
cat $para /tmp/printyn.sh $laction | sshpass -p$kvmpw ssh -Tq -o StrictHostKeyChecking=no $kvm 

exit

zzz=/home/dywang/zzz
for i in 1 2 3; do
	test -f $zzz/vi$i.txt && diff -quN /tmp/vi$i $zzz/vi$i.txt
	print_yn $? vi$i
done

#rm -f /tmp/vi*
sshpass -p$deyupw ssh -q -o StrictHostKeyChecking=no deyu1@$kvm "exit"
echo ${action}4.deyu1_pw:$?
sshpass -p$deyupw ssh -q -o StrictHostKeyChecking=no deyu2@$kvm "exit"
echo ${action}4.deyu2_pw:$?
sshpass -p$deyupw ssh -q -o StrictHostKeyChecking=no deyu4@$kvm "exit"
echo ${action}4.deyu4_pw:$?
sshpass -p123 ssh -q -o StrictHostKeyChecking=no ldapuser1@${kvm} "exit"
echo ${action}4.ldap:$?

wget -q -O re1s.txt http://dywang.csie.cyut.edu.tw/dywang/download/re1.txt
(grep -i 'you' re1s.txt; grep 't[ae]st' re1s.txt; grep '[^gt]oo' re1s.txt; grep '[^0-9][0-9]\{4\}[^0-9]' re1s.txt; grep '[0-9]\{2,\}' re1s.txt; grep '^[A-Z]' re1s.txt; grep '[^\.]$' re1s.txt) > /tmp/result1s.txt
diff -quN /tmp/result1s.txt /home/dywang/zzz/result1.txt
echo ${action}4.re1:$?
rm -f /tmp/result1s.txt >/dev/null 2>&1
