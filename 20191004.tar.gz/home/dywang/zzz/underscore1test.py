#!/usr/bin/python
# coding: utf-8

from underscore1 import *

myc1.__name__
myc1()
_myc2()
