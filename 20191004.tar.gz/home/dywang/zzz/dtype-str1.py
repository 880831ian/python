#!/usr/bin/python
# coding: utf-8
x = "Linda's friend"
print(x,type(x))

