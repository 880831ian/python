#!/usr/bin/python
# coding: utf-8
x = 0b1011 
print (x)
x = 0o7215
print (x)
x = 0x5FE2
print (x)

