#!/usr/bin/python
# coding: utf-8
x = True
y = False
print(type(x),type(y))

