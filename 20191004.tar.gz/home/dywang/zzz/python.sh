today=`date +%Y%m%d`
nowtime=`date +%T`
sid=`ifconfig eth0 | grep 'inet ' | sed 's/.*addr:192.168.1.//' | sed 's/ .*//'`
echo "6-1 $sid 10627046 莊品毅" >../sid
a="\e[32m";b="\e[0m";c="\e[31m";
d="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

t1=abc
t2=my1
t3=my2
t4=str1
t5=underscore1
t6=underscore1test
t7=underscore2
t8=underscore2test
t9=dtype-type1
t10=dtype-type2
t11=dtype-dec
t12=dtype-bin
t13=dtype-ft1
t14=dtype-ft2
t15=dtype-math1
t16=dtype-math2
t17=dtype-math3
t18=dtype-bool1
t19=dtype-bool2
t20=dtype-str1
t21=dtype-str2
t22=dtype-str3
t23=dtype-str4
t24=dtype-c1
t25=dtype-c2
t26=dtype-c3
t27=dtype-c4

clear

echo ${d};
echo "            Python 執行腳本 "
echo "執行日期：${today} 執行時間：${nowtime}"
echo -e "${a}學號姓名檔案from /home/dywang/sid${b}"
cat ../sid
chmod a+x *.py
echo -e "${a}以更改權限 chmod a+x${b}"
num=`expr $num + 1`;
echo -e "${a}輸出${t1}.py  以下執行結果${b}"
./${t1}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t2}.py  以下執行結果${b}"
./${t2}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t3}.py  以下執行結果${b}"
./${t3}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t4}.py  以下執行結果${b}"
./${t4}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t5}.py  以下執行結果${b}"
./${t5}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t6}.py  以下執行結果${b}"
./${t6}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t7}.py  以下執行結果${b}"
./${t7}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t8}.py  以下執行結果${b}"
./${t8}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t8}.py  以下執行結果${b}"
./${t8}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t9}.py  以下執行結果${b}"
./${t9}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t10}.py  以下執行結果${b}"
./${t10}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t11}.py  以下執行結果${b}"
./${t11}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t12}.py  以下執行結果${b}"
./${t12}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t13}.py  以下執行結果${b}"
./${t13}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t14}.py  以下執行結果${b}"
./${t14}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t15}.py  以下執行結果${b}"
./${t15}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t16}.py  以下執行結果${b}"
./${t16}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t17}.py  以下執行結果${b}"
./${t17}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t18}.py  以下執行結果${b}"
./${t18}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t19}.py  以下執行結果${b}"
./${t19}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t20}.py  以下執行結果${b}"
./${t20}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t21}.py  以下執行結果${b}"
./${t21}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t22}.py  以下執行結果${b}"
./${t22}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t23}.py  以下執行結果${b}"
./${t23}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t24}.py  以下執行結果${b}"
./${t24}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t25}.py  以下執行結果${b}"
./${t25}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t26}.py  以下執行結果${b}"
./${t26}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t27}.py  以下執行結果${b}"
./${t27}.py
echo ${d};


echo -e "目前題數：(${a}${num}${b})"
tar zcvf ${today}.tar.gz /home/dywang/zzz/ 1>/dev/null
mv /home/dywang/zzz/${today}.tar.gz /home/dywang/Desktop
echo -e "${a}已備份zzz檔案於 /home/dywang/Desktop${b}"
exit


num=`expr $num + 1`;
echo -e "${a}輸出${t28}.py  以下執行結果${b}"
./${t28}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t29}.py  以下執行結果${b}"
./${t29}.py
echo ${d};
num=`expr $num + 1`;
echo -e "${a}輸出${t30}.py  以下執行結果${b}"
./${t30}.py
echo ${d};

