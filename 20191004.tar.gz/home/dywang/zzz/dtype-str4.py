#!/usr/bin/python
# coding: utf-8
x = 123
y = 456
z1 = str(x) * 3
z2 = str(y) * 2
z = z1+z2
print(z)

