#!/usr/bin/python
# coding: utf-8
x = "Linda's friend"
y = "CSIE CYUT"
z = x +y
print(z)

