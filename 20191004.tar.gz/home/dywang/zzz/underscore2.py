#!/usr/bin/python
# coding: utf-8

class myc1:
	def __init__(self):
		print "myc1"
	def __method(self):
		print "method1 in class myc1"

if __name__ == "__main__":
	print __name__
	myc1()
	myc1()._myc1__method()
else:
	print __name__
