#!/usr/bin/python
# coding: utf-8
x = "ABC\n123"
y = r"ABC\n123"
print (x)
print (y)
