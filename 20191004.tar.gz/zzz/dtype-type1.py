#!/usr/bin/python
# coding: utf-8
x = 55  #變數x
y = x / 11
print(y,type(y))
