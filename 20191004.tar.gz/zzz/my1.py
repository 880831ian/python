#!/usr/bin/python
a=2
b=7
print a+b

