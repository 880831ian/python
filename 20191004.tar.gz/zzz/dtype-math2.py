#!/usr/bin/python
# coding: utf-8
x = -7.6  
y = 2.4
print (pow(y,x))
