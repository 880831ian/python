#!/usr/bin/python
# coding: utf-8
x ,y=291,12.1
print x,y
x ,y=y,x
print x,y
