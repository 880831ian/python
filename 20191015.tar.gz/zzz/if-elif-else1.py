#!/usr/bin/env python
# coding: utf-8

var = raw_input("請輸入一字元")
num = int(var)
if num == 100:
	print "Which is 100"
elif num < 100:
	print("%d < 100" % num)
else:
	print("%d > 100" % num)

