#!/usr/bin/python
# coding: utf-8

list7 = [ '1', '9', 'N', 'h', 'e' ]
list8 = [ '5', 'V', 'l', '2', 'N', 'I', 'i', 'E' ]
list9 = [ 'b', 'd', 'u', '3' ]

var = raw_input("請輸入一數字")
nu = int(var)
if nu > 1:
	
	if nu > 3:
		list7 += list8
		print list7
	elif nu < 3:
		list9 *= 2
		print list9
