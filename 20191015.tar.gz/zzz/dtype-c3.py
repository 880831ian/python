#!/usr/bin/python
# coding: utf-8
x = "ABC"
y = "123"
print (x + "\n" +y )

